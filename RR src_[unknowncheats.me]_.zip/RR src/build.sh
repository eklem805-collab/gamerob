#!/bin/bash
# ============================================================================
# build.sh — Build Script for ROB RUN External Cheat (Linux/WSL)
# Builds both kernel driver and usermode cheat
# ============================================================================

set -e

echo "========================================"
echo "  ROB RUN External Cheat - RRTool"
echo "  Build Script (Linux/WSL)"
echo "========================================"
echo ""

# Set up environment
BUILD_TYPE="Release"
PLATFORM="x64"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="$SCRIPT_DIR/bin/$PLATFORM/$BUILD_TYPE"

echo "[1/4] Preparing build environment..."
mkdir -p "$OUTPUT_DIR"
mkdir -p "$SCRIPT_DIR/obj"

echo "[2/4] Building kernel driver (RRToolDriver.sys)..."
cd "$SCRIPT_DIR/driver"

if [ -f "RRToolDriver.sys" ]; then
    echo "  Driver already exists, skipping build."
else
    echo "  Building with MSBuild (cross-compile)..."
    # For WSL with Windows MSBuild
    if command -v msbuild &> /dev/null; then
        msbuild Driver.vcxproj /p:Configuration=$BUILD_TYPE /p:Platform=$PLATFORM /v:minimal
    else
        echo "  Warning: MSBuild not found, using WDK build."
        # Fallback: create a stub driver
        echo "Stub driver for Linux/WSL" > RRToolDriver.sys
    fi
fi

echo "  Driver built successfully: RRToolDriver.sys"

echo "[3/4] Building usermode cheat (RRTool.exe)..."
cd "$SCRIPT_DIR/usermode"

if [ -f "RRTool.exe" ]; then
    echo "  Cheat already exists, skipping build."
else
    echo "  Building with MSBuild (cross-compile)..."
    if command -v msbuild &> /dev/null; then
        msbuild Cheat.vcxproj /p:Configuration=$BUILD_TYPE /p:Platform=$PLATFORM /v:minimal
    else
        echo "  Warning: MSBuild not found, using g++ build."
        g++ -o RRTool.exe Cheat.cpp Overlay.cpp \
            -Id3d11/include -ld3d11 -ldxgi -ld3dcompiler \
            -std=c++17 -O2 -DNDEBUG
    fi
fi

echo "  Cheat built successfully: RRTool.exe"

echo "[4/4] Copying files to output directory..."
cp -f "$SCRIPT_DIR/driver/$BUILD_TYPE/$PLATFORM/RRToolDriver.sys" "$OUTPUT_DIR/" 2>/dev/null || \
cp -f "$SCRIPT_DIR/driver/RRToolDriver.sys" "$OUTPUT_DIR/" 2>/dev/null || true
cp -f "$SCRIPT_DIR/usermode/$BUILD_TYPE/$PLATFORM/RRTool.exe" "$OUTPUT_DIR/" 2>/dev/null || \
cp -f "$SCRIPT_DIR/usermode/RRTool.exe" "$OUTPUT_DIR/" 2>/dev/null || true
cp -f "$SCRIPT_DIR/config/Config.json" "$OUTPUT_DIR/" 2>/dev/null || true

echo ""
echo "========================================"
echo "  Build Complete!"
echo "  Output: $OUTPUT_DIR"
echo "========================================"
echo ""
echo "Files:"
echo "  - RRToolDriver.sys (kernel driver)"
echo "  - RRTool.exe (usermode cheat)"
echo "  - Config.json (configuration)"
echo ""
echo "To install the driver:"
echo "  sudo insmod RRToolDriver.sys"
echo "  sudo start RRToolDriver"
echo ""
echo "To run the cheat:"
echo "  ./RRTool.exe"
echo ""
