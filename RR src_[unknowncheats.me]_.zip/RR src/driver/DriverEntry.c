// ============================================================================
// DriverEntry.c — ROB RUN Kernel Driver Entry Point
// Entry, device creation, IOCTL dispatch, driver lifecycle
// ============================================================================

#include "Driver.h"

// ============================================================================
// Global State
// ============================================================================

PDEVICE_OBJECT g_DeviceObject = NULL;
UNICODE_STRING g_DeviceName = RTL_CONSTANT_STRING(DEVICE_NAME);
UNICODE_STRING g_SymbolicLink = RTL_CONSTANT_STRING(SYMBOLIC_LINK);

BOOLEAN g_DriverActive = FALSE;
BOOLEAN g_DKOMUnlinked = FALSE;
BOOLEAN g_DSEPatched = FALSE;
BOOLEAN g_PteFlipped = FALSE;
BOOLEAN g_HandleStripped = FALSE;
BOOLEAN g_EacBypassActive = FALSE;

ULONG g_GamePID = 0;
ULONG64 g_GameBase = 0;
ULONG64 g_EntityList = 0;
ULONG64 g_LocalPlayer = 0;
ULONG64 g_BattleEntitiesModel = 0;
ULONG64 g_il2cppDomain = 0;
ULONG64 g_il2cppImage = 0;

CHEAT_CONFIG g_CheatConfig = {0};
ULONG g_CheatState = 0;

// APC state for process attachment
KAPC_STATE g_ApcState;
PEPROCESS g_GameProcess = NULL;

// DKOM state
PLDR_DATA_TABLE_ENTRY g_DKOMEntry = NULL;
LIST_ENTRY g_DKOMFlinkBackup;
LIST_ENTRY g_DKOMBlinkBackup;

// DSE state
ULONG g_OriginalCiOptions = 0;

// ============================================================================
// DriverEntry — Main Entry Point
// ============================================================================

NTSTATUS DriverEntry(
    PDRIVER_OBJECT DriverObject,
    PUNICODE_STRING RegistryPath
)
{
    NTSTATUS status;
    ULONG i;

    UNREFERENCED_PARAMETER(RegistryPath);

    // Initialize cheat config defaults
    RtlZeroMemory(&g_CheatConfig, sizeof(CHEAT_CONFIG));
    g_CheatConfig.EspFov = 90.0f;
    g_CheatConfig.EspDrawDistance = 500.0f;
    g_CheatConfig.EspShowHealth = TRUE;
    g_CheatConfig.EspShowNames = TRUE;
    g_CheatConfig.EspShowDistance = TRUE;
    g_CheatConfig.EspShowTeamColor = TRUE;
    g_CheatConfig.EspShowBoneLines = FALSE;
    g_CheatConfig.EspShowBoxes = TRUE;
    g_CheatConfig.AimFov = 15.0f;
    g_CheatConfig.AimSmoothing = 0.5f;
    g_CheatConfig.AimPrediction = 0.1f;
    g_CheatConfig.AimFovScale = 1.0f;
    g_CheatConfig.AimBoneHead = TRUE;
    g_CheatConfig.AimBoneSpine = FALSE;
    g_CheatConfig.AimSilent = FALSE;
    g_CheatConfig.AimTrigger = FALSE;
    g_CheatConfig.OverlayX = 0.0f;
    g_CheatConfig.OverlayY = 0.0f;
    g_CheatConfig.OverlayWidth = 1920.0f;
    g_CheatConfig.OverlayHeight = 1080.0f;
    g_CheatConfig.OverlayTopmost = TRUE;
    g_CheatConfig.OverlayTransparent = TRUE;
    g_CheatConfig.SpeedMultiplier = 1.0f;
    g_CheatConfig.RadarHack = FALSE;
    g_CheatConfig.AutoAim = FALSE;
    g_CheatConfig.ManualMapMode = TRUE;
    g_CheatConfig.DsePatched = FALSE;
    g_CheatConfig.PteFlipped = FALSE;
    g_CheatConfig.DKOMUnlinked = FALSE;
    g_CheatConfig.HandleStripped = FALSE;
    g_CheatConfig.EacBypassActive = FALSE;
    g_CheatConfig.MaxEntities = MAX_ENTITIES;
    g_CheatConfig.CharacterSlotOffset = OFFSET_CHARACTER_SLOT;
    g_CheatConfig.WorldEntitiesOffset = OFFSET_WORLD_ENTITIES;
    g_CheatConfig.ReplicationGridOffset = OFFSET_REPLICATION_GRID;

    // Create device object
    status = IoCreateDevice(
        DriverObject,
        0,
        &g_DeviceName,
        FILE_DEVICE_UNKNOWN,
        0,
        FALSE,
        &g_DeviceObject
    );

    if (!NT_SUCCESS(status)) {
        return status;
    }

    // Create symbolic link
    status = IoCreateSymbolicLink(&g_SymbolicLink, &g_DeviceName);
    if (!NT_SUCCESS(status)) {
        IoDeleteDevice(g_DeviceObject);
        g_DeviceObject = NULL;
        return status;
    }

    // Initialize dispatch routines
    for (i = 0; i < IRP_MJ_MAXIMUM_FUNCTION; i++) {
        DriverObject->MajorFunction[i] = IoDefaultDeviceHandler;
    }

    DriverObject->MajorFunction[IRP_MJ_CREATE] = DispatchCreate;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = DispatchClose;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DispatchIoctl;
    DriverObject->MajorFunction[IRP_MJ_WRITE] = DispatchWrite;
    DriverObject->DriverUnload = DriverUnload;

    // Apply initial EAC bypass primitives
    // 1. DSE patch (allows unsigned driver to load)
    status = ApplyDSEPatch();
    if (NT_SUCCESS(status)) {
        g_DSEPatched = TRUE;
        g_CheatConfig.DsePatched = TRUE;
    }

    // 2. PTE-exec flip (hide driver pages from module census)
    status = ApplyPTEFlip(TRUE);
    if (NT_SUCCESS(status)) {
        g_PteFlipped = TRUE;
        g_CheatConfig.PteFlipped = TRUE;
    }

    // 3. DKOM unlink (hide from PsLoadedModuleList)
    status = ApplyDKOMUnlink();
    if (NT_SUCCESS(status)) {
        g_DKOMUnlinked = TRUE;
        g_CheatConfig.DKOMUnlinked = TRUE;
    }

    // 4. Handle stripping
    status = ApplyHandleStripping();
    if (NT_SUCCESS(status)) {
        g_HandleStripped = TRUE;
        g_CheatConfig.HandleStripped = TRUE;
    }

    g_EacBypassActive = TRUE;
    g_CheatConfig.EacBypassActive = TRUE;
    g_DriverActive = TRUE;

    return STATUS_SUCCESS;
}

// ============================================================================
// DriverUnload
// ============================================================================

VOID DriverUnload(PDRIVER_OBJECT DriverObject)
{
    // Revert EAC bypass in reverse order
    if (g_HandleStripped) {
        RevertHandleStripping();
    }

    if (g_DKOMUnlinked) {
        RevertDKOMUnlink();
    }

    if (g_PteFlipped) {
        ApplyPTEFlip(FALSE);
    }

    if (g_DSEPatched) {
        RevertDSEPatch();
    }

    // Detach from game process if attached
    if (g_GameProcess != NULL) {
        KeUnstackDetachProcess(&g_ApcState);
        ObDereferenceObject(g_GameProcess);
        g_GameProcess = NULL;
        g_GamePID = 0;
    }

    // Delete symbolic link
    IoDeleteSymbolicLink(&g_SymbolicLink);

    // Delete device object
    if (g_DeviceObject != NULL) {
        IoDeleteDevice(g_DeviceObject);
        g_DeviceObject = NULL;
    }

    g_DriverActive = FALSE;
}

// ============================================================================
// DispatchCreate
// ============================================================================

NTSTATUS DispatchCreate(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);

    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// ============================================================================
// DispatchClose
// ============================================================================

NTSTATUS DispatchClose(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);

    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// ============================================================================
// DispatchIoctl — Main IOCTL dispatcher
// ============================================================================

NTSTATUS DispatchIoctl(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    ULONG controlCode = stack->Parameters.DeviceIoControl.IoControlCode;
    PVOID buffer = Irp->AssociatedIrp.SystemBuffer;
    ULONG bufferLength = stack->Parameters.DeviceIoControl.InputBufferLength;
    ULONG outputLength = stack->Parameters.DeviceIoControl.OutputBufferLength;
    NTSTATUS status = STATUS_SUCCESS;

    switch (controlCode) {
        case IOCTL_READ_MEMORY: {
            if (bufferLength < sizeof(IOCTL_READ_DATA) ||
                outputLength < sizeof(IOCTL_READ_DATA)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            PIOCTL_READ_DATA readData = (PIOCTL_READ_DATA)buffer;
            ULONG64 value = 0;

            if (IsProcessAttached()) {
                status = ReadGameMemory(readData->Address, &value, readData->Size);
            } else {
                // Fallback: use MmCopyVirtualMemory with game process
                PEPROCESS gameProc;
                status = PsLookupProcessByProcessId(
                    (HANDLE)(ULONG_PTR)readData->ProcessId,
                    &gameProc
                );
                if (NT_SUCCESS(status)) {
                    SIZE_T bytesRead;
                    status = MmCopyVirtualMemory(
                        gameProc,
                        (PVOID)(ULONG_PTR)readData->Address,
                        PsGetCurrentProcess(),
                        &value,
                        readData->Size,
                        KernelMode,
                        &bytesRead
                    );
                    ObDereferenceObject(gameProc);
                }
            }

            if (NT_SUCCESS(status)) {
                readData->Output = value;
            }

            break;
        }

        case IOCTL_WRITE_MEMORY: {
            if (bufferLength < sizeof(IOCTL_WRITE_DATA)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            PIOCTL_WRITE_DATA writeData = (PIOCTL_WRITE_DATA)buffer;
            PVOID input = (PVOID)(ULONG_PTR)writeData->Input;

            if (IsProcessAttached()) {
                status = WriteGameMemory(writeData->Address, input, writeData->Size);
            } else {
                PEPROCESS gameProc;
                status = PsLookupProcessByProcessId(
                    (HANDLE)(ULONG_PTR)writeData->ProcessId,
                    &gameProc
                );
                if (NT_SUCCESS(status)) {
                    SIZE_T bytesWritten;
                    status = MmCopyVirtualMemory(
                        PsGetCurrentProcess(),
                        input,
                        gameProc,
                        (PVOID)(ULONG_PTR)writeData->Address,
                        writeData->Size,
                        KernelMode,
                        &bytesWritten
                    );
                    ObDereferenceObject(gameProc);
                }
            }

            break;
        }

        case IOCTL_PROCESS_ATTACH: {
            if (bufferLength < sizeof(ULONG)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            ULONG pid = *(PULONG)buffer;
            status = AttachToGameProcess(pid);
            if (NT_SUCCESS(status)) {
                g_GamePID = pid;
            }
            break;
        }

        case IOCTL_GET_EPROCESS: {
            if (outputLength < sizeof(ULONG64)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            ULONG64 epAddr = (ULONG64)(ULONG_PTR)GetGameProcessEPROCESS();
            *(PULONG64)buffer = epAddr;
            break;
        }

        case IOCTL_DKOM_UNLINK: {
            status = ApplyDKOMUnlink();
            if (NT_SUCCESS(status)) {
                g_DKOMUnlinked = TRUE;
                g_CheatConfig.DKOMUnlinked = TRUE;
            }
            break;
        }

        case IOCTL_DSE_PATCH: {
            status = ApplyDSEPatch();
            if (NT_SUCCESS(status)) {
                g_DSEPatched = TRUE;
                g_CheatConfig.DsePatched = TRUE;
            }
            break;
        }

        case IOCTL_PTE_FLIP: {
            BOOLEAN enable = (*(PULONG)buffer) ? TRUE : FALSE;
            status = ApplyPTEFlip(enable);
            if (NT_SUCCESS(status)) {
                g_PteFlipped = enable;
                g_CheatConfig.PteFlipped = enable;
            }
            break;
        }

        case IOCTL_GET_MODULE_BASE: {
            if (bufferLength < sizeof(CHAR[MAX_MODULE_NAME]) ||
                outputLength < sizeof(ULONG64)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            PCCH moduleName = (PCCH)buffer;
            ULONG64 base = GetModuleBase(moduleName);
            *(PULONG64)buffer = base;
            break;
        }

        case IOCTL_GET_MODULE_HASH: {
            if (bufferLength < sizeof(CHAR[MAX_MODULE_NAME])) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            PCCH moduleName = (PCCH)buffer;
            ULONG hash = GetModuleNameHash(moduleName);
            *(PULONG)buffer = hash;
            break;
        }

        case IOCTL_GET_GAME_INFO: {
            if (outputLength < sizeof(IOCTL_GAME_INFO)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            PIOCTL_GAME_INFO gameInfo = (PIOCTL_GAME_INFO)buffer;
            gameInfo->EntityList = g_EntityList;
            gameInfo->EntityCount = 0;
            gameInfo->LocalPlayer = g_LocalPlayer;
            gameInfo->BattleEntitiesModel = g_BattleEntitiesModel;
            gameInfo->il2cppDomain = g_il2cppDomain;
            gameInfo->il2cppImage = g_il2cppImage;
            gameInfo->PlayerCount = g_CheatConfig.PlayerCount;
            gameInfo->MaxEntities = g_CheatConfig.MaxEntities;
            break;
        }

        case IOCTL_ENABLE_CHEAT: {
            if (bufferLength < sizeof(ULONG)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            ULONG feature = *(PULONG)buffer;
            g_CheatState |= feature;
            status = STATUS_SUCCESS;
            break;
        }

        case IOCTL_SET_CHEAT_STATE: {
            if (bufferLength < sizeof(ULONG)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            ULONG newState = *(PULONG)buffer;
            g_CheatState = newState;
            status = STATUS_SUCCESS;
            break;
        }

        case IOCTL_READ_BONE: {
            if (bufferLength < sizeof(IOCTL_BONE_DATA) ||
                outputLength < sizeof(IOCTL_BONE_DATA)) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            PIOCTL_BONE_DATA boneData = (PIOCTL_BONE_DATA)buffer;
            if (IsProcessAttached()) {
                PVOID posBuffer = ExAllocatePool2(
                    PoolNonPaged,
                    sizeof(FLOAT) * 3,
                    0
                );
                if (posBuffer) {
                    status = ReadGameMemory(
                        boneData->BonePosition,
                        posBuffer,
                        sizeof(FLOAT) * 3
                    );
                    if (NT_SUCCESS(status)) {
                        boneData->X = ((PFLOAT)posBuffer)[0];
                        boneData->Y = ((PFLOAT)posBuffer)[1];
                        boneData->Z = ((PFLOAT)posBuffer)[2];
                    }
                    ExFreePool2(posBuffer, 0, 0);
                }
            }
            break;
        }

        default:
            status = STATUS_INVALID_DEVICE_REQUEST;
            break;
    }

    Irp->IoStatus.Status = status;
    Irp->IoStatus.Information = outputLength;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return status;
}

// ============================================================================
// DispatchWrite — Handle write IRPs
// ============================================================================

NTSTATUS DispatchWrite(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);

    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// ============================================================================
// ValidateEACBypass — Check that all bypass primitives are active
// ============================================================================

BOOLEAN ValidateEACBypass(VOID)
{
    return (g_DKOMUnlinked && g_DSEPatched && g_PteFlipped && g_HandleStripped);
}
