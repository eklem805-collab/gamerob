// ============================================================================
// Driver.h — ROB RUN Kernel Driver Header
// Target: ROB RUN (Steam, il2cpp + EAC)
// MSVC + WDK (x64)
// ============================================================================

#pragma once

#include <ntifs.h>
#include <ntddk.h>
#include <ntimage.h>
#include <wdf.h>

// ============================================================================
// IOCTL Codes
// ============================================================================

#define IOCTL_READ_MEMORY         CTL_CODE(FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_WRITE_MEMORY        CTL_CODE(FILE_DEVICE_UNKNOWN, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PROCESS_ATTACH      CTL_CODE(FILE_DEVICE_UNKNOWN, 0x803, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_GET_EPROCESS        CTL_CODE(FILE_DEVICE_UNKNOWN, 0x804, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_DKOM_UNLINK         CTL_CODE(FILE_DEVICE_UNKNOWN, 0x805, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_DSE_PATCH           CTL_CODE(FILE_DEVICE_UNKNOWN, 0x806, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PTE_FLIP            CTL_CODE(FILE_DEVICE_UNKNOWN, 0x807, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_GET_MODULE_BASE     CTL_CODE(FILE_DEVICE_UNKNOWN, 0x808, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_GET_MODULE_HASH     CTL_CODE(FILE_DEVICE_UNKNOWN, 0x809, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_GET_GAME_INFO       CTL_CODE(FILE_DEVICE_UNKNOWN, 0x80A, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_ENABLE_CHEAT        CTL_CODE(FILE_DEVICE_UNKNOWN, 0x80B, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_SET_CHEAT_STATE     CTL_CODE(FILE_DEVICE_UNKNOWN, 0x80C, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_READ_BONE           CTL_CODE(FILE_DEVICE_UNKNOWN, 0x80D, METHOD_BUFFERED, FILE_ANY_ACCESS)

// ============================================================================
// IOCTL Data Structures
// ============================================================================

typedef struct _IOCTL_READ_DATA {
    ULONG   ProcessId;
    ULONG64 Address;
    ULONG   Size;
    ULONG   DataType;       // 0=uint32, 1=uint64, 2=float, 3=double, 4=vector3
    ULONG   Reserved;
    ULONG64 Output;
} IOCTL_READ_DATA, *PIOCTL_READ_DATA;

typedef struct _IOCTL_WRITE_DATA {
    ULONG   ProcessId;
    ULONG64 Address;
    ULONG   Size;
    ULONG   DataType;
    ULONG   Reserved;
    ULONG64 Input;
} IOCTL_WRITE_DATA, *PIOCTL_WRITE_DATA;

typedef struct _IOCTL_GAME_INFO {
    ULONG64 EntityList;
    ULONG   EntityCount;
    ULONG64 LocalPlayer;
    ULONG64 BattleEntitiesModel;
    ULONG64 il2cppDomain;
    ULONG64 il2cppImage;
    ULONG   PlayerCount;
    ULONG   MaxEntities;
    ULONG   Reserved;
} IOCTL_GAME_INFO, *PIOCTL_GAME_INFO;

typedef struct _IOCTL_BONE_DATA {
    ULONG64 BoneAddress;
    ULONG64 BonePosition;
    FLOAT   X, Y, Z;
    ULONG   BoneIndex;
    ULONG   Reserved;
} IOCTL_BONE_DATA, *PIOCTL_BONE_DATA;

// ============================================================================
// ROB RUN Offsets (from UC Thread — 779959)
// ============================================================================

// BattleEntitiesModel (namespace: Game.Battle)
#define OFFSET_BATTLE_ENTITIES_MODEL    0x50   // _entitiesParamsModel (Dictionary)
#define OFFSET_ENTITIES_DICT            0x50   // _models (Dictionary base)
#define OFFSET_PLOTS_DICT               0x58   // _plotsModels (Dictionary)
#define OFFSET_WORLD_ENTITIES           0x60   // _worldEntitiesModel
#define OFFSET_REPLICATION_GRID         0x68   // _replicationGridLayers
#define OFFSET_CHARACTER_SLOT           0x80   // _characterSlotModel
#define OFFSET_VEHICLES                 0x88   // _vehiclesModel
#define OFFSET_LOCATION_PLOT_SPOTS      0x90   // _locationPlotSpotsModel
#define OFFSET_LOCATION                 0x98   // _location
#define OFFSET_SECTOR                   0xA0   // _sector
#define OFFSET_SETTLEMENT_BONUS         0xA8   // _settlementBonusModel
#define OFFSET_GLOBAL_MODEL             0xB0   // _globalModel
#define OFFSET_TIME_MODEL               0xB8   // _timeModel
#define OFFSET_LAPTOP_DIRTY_CASH        0xC0   // _laptopDirtyCashModel
#define OFFSET_PLOT_GRADE               0xC8   // _plotGrade
#define OFFSET_PLAYER                   0xD0   // _player (PlayerEntityModel)
#define OFFSET_SELF_PLOT                0xD8   // _selfPlot (PlotEntityModel)
#define OFFSET_ENTITY_MODELS            0xE0   // _entityModels (ReadOnlyDictionary)

// BattleEntitiesModel top-level fields
#define OFFSET_PHYSICS_SCENE            0x10
#define OFFSET_PLAYER_BATTLE_MODEL      0x18
#define OFFSET_INVENTORY_MODELS         0x20
#define OFFSET_WORLD_SETTINGS_OVERRIDE  0x28
#define OFFSET_ENTITIES_PARAMS          0x30
#define OFFSET_SETTLEMENT_MODEL         0x38
#define OFFSET_PHYSICS_BODIES           0x40
#define OFFSET_LOCATION_DESC_ENTITIES   0x48

// ============================================================================
// Bone Chain Offsets
// ============================================================================

#define BONE_KVIEW_OFFSET           0x108    // BattleCharacterEntityView
#define BONE_TRANSFORM_OFFSET       0x10     // UnityEngine.Transform
#define BONE_HEAD_ADAPTATION        0x108    // HeadAdaptationManualBehavior
#define BONE_SPINE_ADAPTATION       0xF8     // SpineAdaptationManualBehavior
#define BONE_HEAD_POSITION          0xE8     // <HeadPosition> Transform
#define BONE_HEAD_INDEX             0x40     // boneHead offset
#define BONE_SPINE_INDEX            0x40     // boneSpine offset
#define BONE_TARGET_INDEX           0x28     // _boneTarget Transform
#define BONE_CHAR_VIEWS_COUNT       272      // charViews count
#define BONE_CACHED_PTR             0x10     // m_CachedPtr (Transform)

// ============================================================================
// EAC Bypass Constants
// ============================================================================

#define MAX_ENTITIES                512      // Max entity count
#define MAX_BONES_PER_ENTITY        32       // Bones per entity
#define DKOM_UNLINK_TIMEOUT_MS      5000     // DKOM timeout
#define DSE_PATCH_TIMEOUT_MS        3000     // DSE patch timeout
#define DRIVER_NAME                 L"RRToolDriver"
#define DEVICE_NAME                 L"\\Device\\RRToolDriver"
#define SYMBOLIC_LINK               L"\\DosDevices\\RRToolDriver"

// ============================================================================
// Cheat State Flags
// ============================================================================

#define CHEAT_ESP_ENABLED           (1 << 0)
#define CHEAT_AIMBOT_ENABLED        (1 << 1)
#define CHEAT_TRIGGERBOT_ENABLED    (1 << 2)
#define CHEAT_RADAR_HACK            (1 << 3)
#define CHEAT_SPEED_HACK            (1 << 4)
#define CHEAT_FOV_VISIBLE           (1 << 5)
#define CHEAT_HEALTH_BAR            (1 << 6)
#define CHEAT_PLAYER_NAMES          (1 << 7)
#define CHEAT_DISTANCE_DISPLAY      (1 << 8)
#define CHEAT_TEAM_COLORING         (1 << 9)

// ============================================================================
// DKOM Constants
// ============================================================================

#define LDR_DATA_TABLE_ENTRY_SIZE   0x60     // Approximate size on Win11
#define MAX_MODULE_NAME             256

// ============================================================================
// DSE Constants
// ============================================================================

#define DSE_BIT_MASK                0x1      // Bit 0 = DSE enabled
#define CI_OPTIONS_OFFSET           0x18     // Offset to g_CiOptions in ci.dll (ntkrnlmp.pdb-derived)

// ============================================================================
// PTE Constants
// ============================================================================

#define PAGE_EXECUTE_READWRITE      0x40
#define PAGE_EXECUTE_WRITECOPY      0x80
#define PAGE_EXECUTE                0x20
#define PAGE_WRITE_COMBINE          0x00400000
#define PAGE_WRITE_TARGET           0x00200000

// ============================================================================
// Cheat Configuration (loaded from Config.json)
// ============================================================================

typedef struct _CHEAT_CONFIG {
    // ESP settings
    FLOAT   EspFov;
    FLOAT   EspDrawDistance;
    BOOLEAN EspShowHealth;
    BOOLEAN EspShowNames;
    BOOLEAN EspShowDistance;
    BOOLEAN EspShowTeamColor;
    BOOLEAN EspShowBoneLines;
    BOOLEAN EspShowBoxes;

    // Aimbot settings
    FLOAT   AimFov;
    FLOAT   AimSmoothing;
    FLOAT   AimPrediction;
    FLOAT   AimFovScale;
    BOOLEAN AimBoneHead;
    BOOLEAN AimBoneSpine;
    BOOLEAN AimSilent;
    BOOLEAN AimTrigger;

    // Overlay settings
    FLOAT   OverlayX;
    FLOAT   OverlayY;
    FLOAT   OverlayWidth;
    FLOAT   OverlayHeight;
    BOOLEAN OverlayTopmost;
    BOOLEAN OverlayTransparent;

    // General settings
    FLOAT   SpeedMultiplier;
    BOOLEAN RadarHack;
    BOOLEAN AutoAim;
    BOOLEAN ManualMapMode;
    BOOLEAN DsePatched;
    BOOLEAN PteFlipped;
    BOOLEAN DKOMUnlinked;
    BOOLEAN HandleStripped;
    BOOLEAN EacBypassActive;

    // RobRun specific
    ULONG64 GameBase;
    ULONG64 EntityList;
    ULONG64 LocalPlayer;
    ULONG64 BattleEntitiesModel;
    ULONG64 il2cppDomain;
    ULONG64 il2cppImage;
    ULONG   GamePID;
    ULONG   MaxEntities;
    ULONG   PlayerCount;
    ULONG   CharacterSlotOffset;
    ULONG   WorldEntitiesOffset;
    ULONG   ReplicationGridOffset;

} CHEAT_CONFIG, *PCHEAT_CONFIG;

// ============================================================================
// Driver Globals
// ============================================================================

extern PDEVICE_OBJECT g_DeviceObject;
extern UNICODE_STRING g_DeviceName;
extern UNICODE_STRING g_SymbolicLink;
extern BOOLEAN g_DriverActive;
extern BOOLEAN g_DKOMUnlinked;
extern BOOLEAN g_DSEPatched;
extern BOOLEAN g_PteFlipped;
extern BOOLEAN g_HandleStripped;
extern BOOLEAN g_EacBypassActive;
extern ULONG g_GamePID;
extern ULONG64 g_GameBase;
extern ULONG64 g_EntityList;
extern ULONG64 g_LocalPlayer;
extern ULONG64 g_BattleEntitiesModel;
extern ULONG64 g_il2cppDomain;
extern ULONG64 g_il2cppImage;
extern CHEAT_CONFIG g_CheatConfig;
extern ULONG g_CheatState;

// ============================================================================
// Function Prototypes
// ============================================================================

// DriverEntry.c
DRIVER_INITIALIZE DriverEntry;
VOID DriverUnload(PDRIVER_OBJECT DriverObject);
NTSTATUS DispatchCreate(PDEVICE_OBJECT DeviceObject, PIRP Irp);
NTSTATUS DispatchClose(PDEVICE_OBJECT DeviceObject, PIRP Irp);
NTSTATUS DispatchIoctl(PDEVICE_OBJECT DeviceObject, PIRP Irp);
NTSTATUS DispatchWrite(PDEVICE_OBJECT DeviceObject, PIRP Irp);

// Memory.c
NTSTATUS ReadGameMemory(
    ULONG64 address,
    PVOID buffer,
    SIZE_T size
);

NTSTATUS WriteGameMemory(
    ULONG64 address,
    PVOID buffer,
    SIZE_T size
);

NTSTATUS AttachToGameProcess(
    ULONG pid
);

VOID DetachFromGameProcess(
    VOID
);

ULONG64 GetGameProcessEPROCESS(
    VOID
);

BOOLEAN IsProcessAttached(
    VOID
);

// Hide.c
NTSTATUS ApplyDKOMUnlink(
    VOID
);

VOID RevertDKOMUnlink(
    VOID
);

NTSTATUS ApplyDSEPatch(
    VOID
);

VOID RevertDSEPatch(
    VOID
);

NTSTATUS ApplyPTEFlip(
    BOOLEAN enable
);

BOOLEAN IsDKOMUnlinked(
    VOID
);

BOOLEAN IsDSEPatched(
    VOID
);

// Handle.c
NTSTATUS ApplyHandleStripping(
    VOID
);

VOID RevertHandleStripping(
    VOID
);

BOOLEAN IsHandleStripped(
    VOID
);

// Utility
ULONG64 GetModuleBase(
    PCCH moduleName
);

ULONG GetModuleNameHash(
    PCCH moduleName
);

BOOLEAN ValidateEACBypass(
    VOID
);
