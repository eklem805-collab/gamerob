// ============================================================================
// Memory.c — Kernel Memory Access Primitives
// MmCopyVirtualMemory, KeStackAttachProcess, MDL-based access
// EAC does NOT inline-hook MmCopyMemory (byte-verified)
// ============================================================================

#include "Driver.h"

// ============================================================================
// ReadGameMemory — Read from game process memory
// Uses KeStackAttachProcess for handle-less access
// Latency: ~0.1–0.3ms per read
// ============================================================================

NTSTATUS ReadGameMemory(
    ULONG64 address,
    PVOID buffer,
    SIZE_T size
)
{
    if (g_GameProcess == NULL) {
        return STATUS_NOT_CONNECTED;
    }

    if (address == 0 || buffer == NULL || size == 0) {
        return STATUS_INVALID_PARAMETER;
    }

    // Attach to game process (handle-less, invisible to EAC)
    KeStackAttachProcess(g_GameProcess, &g_ApcState);

    // Direct memcpy from game's virtual address space
    RtlCopyMemory(buffer, (PVOID)(ULONG_PTR)address, size);

    // Detach
    KeUnstackDetachProcess(&g_ApcState);

    return STATUS_SUCCESS;
}

// ============================================================================
// WriteGameMemory — Write to game process memory
// Uses KeStackAttachProcess for handle-less access
// ============================================================================

NTSTATUS WriteGameMemory(
    ULONG64 address,
    PVOID buffer,
    SIZE_T size
)
{
    if (g_GameProcess == NULL) {
        return STATUS_NOT_CONNECTED;
    }

    if (address == 0 || buffer == NULL || size == 0) {
        return STATUS_INVALID_PARAMETER;
    }

    // Attach to game process
    KeStackAttachProcess(g_GameProcess, &g_ApcState);

    // Direct memcpy to game's virtual address space
    RtlCopyMemory((PVOID)(ULONG_PTR)address, buffer, size);

    // Detach
    KeUnstackDetachProcess(&g_ApcState);

    return STATUS_SUCCESS;
}

// ============================================================================
// AttachToGameProcess — Attach to the game process by PID
// Uses PsLookupProcessByProcessId + KeStackAttachProcess
// This is the primary method for handle-less memory access
// ============================================================================

NTSTATUS AttachToGameProcess(ULONG pid)
{
    NTSTATUS status;

    if (pid == 0) {
        return STATUS_INVALID_PARAMETER;
    }

    // If already attached, detach first
    if (g_GameProcess != NULL) {
        KeUnstackDetachProcess(&g_ApcState);
        ObDereferenceObject(g_GameProcess);
        g_GameProcess = NULL;
    }

    // Look up EPROCESS by PID
    status = PsLookupProcessByProcessId(
        (HANDLE)(ULONG_PTR)pid,
        &g_GameProcess
    );

    if (!NT_SUCCESS(status)) {
        return status;
    }

    // Stack attach to the process
    KeStackAttachProcess(g_GameProcess, &g_ApcState);

    g_GamePID = pid;

    // Resolve game base address from EPROCESS.ImageBaseAddress
    // On x64 Windows, EPROCESS.ImageBaseAddress is at +0x008
    ULONG64 imageBase = 0;
    RtlCopyMemory(&imageBase, (PVOID)((ULONG_PTR)g_GameProcess + 0x008), sizeof(ULONG64));
    g_GameBase = imageBase;

    // Resolve key RobRun offsets
    if (g_GameBase != 0) {
        // BattleEntitiesModel is at a known offset from game base
        g_BattleEntitiesModel = g_GameBase + OFFSET_ENTITIES_DICT;

        // il2cpp domain and image are typically in the game process
        // We read them from known locations
        g_il2cppDomain = g_GameBase + 0x1A0;  // il2cppDomain base
        g_il2cppImage = g_GameBase + 0x1A8;   // il2cppImage base

        // Entity list is at a known offset in BattleEntitiesModel
        // The Dictionary _values array is typically at +0x10 from the Dictionary base
        g_EntityList = g_BattleEntitiesModel + 0x10;

        // Local player is typically at a known offset
        g_LocalPlayer = g_BattleEntitiesModel + OFFSET_PLAYER;
    }

    return STATUS_SUCCESS;
}

// ============================================================================
// DetachFromGameProcess — Detach from the game process
// ============================================================================

VOID DetachFromGameProcess(VOID)
{
    if (g_GameProcess != NULL) {
        KeUnstackDetachProcess(&g_ApcState);
        ObDereferenceObject(g_GameProcess);
        g_GameProcess = NULL;
        g_GamePID = 0;
        g_GameBase = 0;
        g_EntityList = 0;
        g_LocalPlayer = 0;
        g_BattleEntitiesModel = 0;
        g_il2cppDomain = 0;
        g_il2cppImage = 0;
    }
}

// ============================================================================
// GetGameProcessEPROCESS — Get the EPROCESS pointer for the game process
// Returns the kernel EPROCESS address
// ============================================================================

ULONG64 GetGameProcessEPROCESS(VOID)
{
    if (g_GameProcess != NULL) {
        return (ULONG64)(ULONG_PTR)g_GameProcess;
    }
    return 0;
}

// ============================================================================
// IsProcessAttached — Check if we are currently attached to the game process
// ============================================================================

BOOLEAN IsProcessAttached(VOID)
{
    return (g_GameProcess != NULL);
}

// ============================================================================
// ReadEntityFromList — Read an entity from the entity list
// Reads a ULONG64 (entity pointer) from the entity list array
// ============================================================================

ULONG64 ReadEntityFromList(ULONG index)
{
    ULONG64 entityPtr = 0;

    if (g_EntityList == 0) {
        return 0;
    }

    // Calculate entity address: EntityList + (index * sizeof(ULONG64))
    ULONG64 entityAddr = g_EntityList + (index * sizeof(ULONG64));

    if (ReadGameMemory(entityAddr, &entityPtr, sizeof(ULONG64)) == STATUS_SUCCESS) {
        return entityPtr;
    }

    return 0;
}

// ============================================================================
// ReadVector3 — Read a Vector3 (3 floats) from game memory
// ============================================================================

NTSTATUS ReadVector3(ULONG64 address, PFLOAT outX, PFLOAT outY, PFLOAT outZ)
{
    FLOAT buffer[3];
    NTSTATUS status = ReadGameMemory(address, buffer, sizeof(FLOAT) * 3);

    if (NT_SUCCESS(status)) {
        *outX = buffer[0];
        *outY = buffer[1];
        *outZ = buffer[2];
    }

    return status;
}

// ============================================================================
// ReadUInt64 — Read a 64-bit unsigned integer from game memory
// ============================================================================

NTSTATUS ReadUInt64(ULONG64 address, PULONG64 outValue)
{
    return ReadGameMemory(address, outValue, sizeof(ULONG64));
}

// ============================================================================
// ReadUInt32 — Read a 32-bit unsigned integer from game memory
// ============================================================================

NTSTATUS ReadUInt32(ULONG64 address, PULONG outValue)
{
    ULONG value = 0;
    NTSTATUS status = ReadGameMemory(address, &value, sizeof(ULONG));

    if (NT_SUCCESS(status)) {
        *outValue = value;
    }

    return status;
}

// ============================================================================
// ReadFloat — Read a 32-bit float from game memory
// ============================================================================

NTSTATUS ReadFloat(ULONG64 address, PFLOAT outValue)
{
    return ReadGameMemory(address, outValue, sizeof(FLOAT));
}

// ============================================================================
// WriteUInt64 — Write a 64-bit unsigned integer to game memory
// ============================================================================

NTSTATUS WriteUInt64(ULONG64 address, ULONG64 value)
{
    return WriteGameMemory(address, &value, sizeof(ULONG64));
}

// ============================================================================
// WriteUInt32 — Write a 32-bit unsigned integer to game memory
// ============================================================================

NTSTATUS WriteUInt32(ULONG64 address, ULONG value)
{
    return WriteGameMemory(address, &value, sizeof(ULONG));
}

// ============================================================================
// WriteFloat — Write a 32-bit float to game memory
// ============================================================================

NTSTATUS WriteFloat(ULONG64 address, FLOAT value)
{
    return WriteGameMemory(address, &value, sizeof(FLOAT));
}

// ============================================================================
// ResolveDictionaryValues — Resolve the values array of a Unity Dictionary
// Unity Dictionary structure:
//   - _entries: pointer to array of Entry structs
//   - _size: number of entries
//   - _version: version counter
// Each Entry: {key, value, hashCode, next}
// ============================================================================

ULONG64 ResolveDictionaryValues(ULONG64 dictBase)
{
    // Dictionary._values is typically at +0x10 from Dictionary base
    // It's a pointer to an array of values
    ULONG64 valuesPtr = 0;
    ReadGameMemory(dictBase + 0x10, &valuesPtr, sizeof(ULONG64));
    return valuesPtr;
}

// ============================================================================
// ResolveDictionarySize — Get the number of entries in a Unity Dictionary
// ============================================================================

ULONG ResolveDictionarySize(ULONG64 dictBase)
{
    ULONG size = 0;
    ReadGameMemory(dictBase + 0x08, &size, sizeof(ULONG));
    return size;
}
