@echo off
REM ============================================================================
REM build.bat — Build Script for ROB RUN External Cheat
REM Builds both kernel driver and usermode cheat
REM ============================================================================

echo ========================================
echo   ROB RUN External Cheat - RRTool
echo   Build Script
echo ========================================
echo.

REM Set up environment
set BUILD_TYPE=Release
set PLATFORM=x64
set SOLUTION_DIR=%~dp0
set OUTPUT_DIR=%SOLUTION_DIR%bin\%PLATFORM%\%BUILD_TYPE%

echo [1/4] Preparing build environment...
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"
if not exist "%SOLUTION_DIR%obj" mkdir "%SOLUTION_DIR%obj"

echo [2/4] Building kernel driver (RRToolDriver.sys)...
cd /d "%SOLUTION_DIR%driver"

if exist "RRToolDriver.sys" (
    echo   Driver already exists, skipping build.
) else (
    echo   Building with MSBuild...
    msbuild Driver.vcxproj /p:Configuration=%BUILD_TYPE% /p:Platform=%PLATFORM% /v:minimal
    if errorlevel 1 (
        echo   ERROR: Driver build failed.
        exit /b 1
    )
)

echo   Driver built successfully: RRToolDriver.sys

echo [3/4] Building usermode cheat (RRTool.exe)...
cd /d "%SOLUTION_DIR%usermode"

if exist "RRTool.exe" (
    echo   Cheat already exists, skipping build.
) else (
    echo   Building with MSBuild...
    msbuild Cheat.vcxproj /p:Configuration=%BUILD_TYPE% /p:Platform=%PLATFORM% /v:minimal
    if errorlevel 1 (
        echo   ERROR: Cheat build failed.
        exit /b 1
    )
)

echo   Cheat built successfully: RRTool.exe

echo [4/4] Copying files to output directory...
copy /y "%SOLUTION_DIR%driver\%BUILD_TYPE%\%PLATFORM%\RRToolDriver.sys" "%OUTPUT_DIR%\" >nul
copy /y "%SOLUTION_DIR%usermode\%BUILD_TYPE%\%PLATFORM%\RRTool.exe" "%OUTPUT_DIR%\" >nul
copy /y "%SOLUTION_DIR%config\Config.json" "%OUTPUT_DIR%\" >nul

echo.
echo ========================================
echo   Build Complete!
echo   Output: %OUTPUT_DIR%
echo ========================================
echo.
echo Files:
echo   - RRToolDriver.sys (kernel driver)
echo   - RRTool.exe (usermode cheat)
echo   - Config.json (configuration)
echo.
echo To install the driver:
echo   sc create RRToolDriver binPath= "%OUTPUT_DIR%\RRToolDriver.sys" type= kernel
echo   sc start RRToolDriver
echo.
echo To run the cheat:
echo   "%OUTPUT_DIR%\RRTool.exe"
echo.
