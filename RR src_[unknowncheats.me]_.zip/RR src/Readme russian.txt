# RRTool — внешний чит на основе драйвера ядра для ROB RUN

**Цель:** ROB RUN (Steam, il2cpp + EAC)  
**Сборка:** MSVC + WDK (x64)  
**Дата:** 2026-11-15  
**Источник:** [UC Thread](https://www.unknowncheats.me/forum/other-fps-games/779959-rob-run-reversal-structs-offsets.html)  
**Исследование:** [ac-research](https://github.com/ac-research/game-security)

---

## Структура проекта

```
src/
├── driver/                    # Исходники драйвера ядра
│   ├── Driver.h              # Заголовок: структуры, IOCTL-коды, оффсеты RobRun
│   ├── DriverEntry.c         # Точка входа, создание устройства, диспетчеризация IOCTL
│   ├── Memory.c              # MmCopyVirtualMemory, MDL, подключение к процессу
│   ├── Hide.c                # DKOM unlink, патч DSE, переключение PTE-exec
│   ├── Handle.c              # Противодействие ObRegisterCallbacks, срезание прав хендлов
│   ├── RRToolDriver.inf      # Файл установки драйвера
│   └── Driver.vcxproj        # Файл проекта MSVC
├── usermode/                  # Исходники чита в юзермоде
│   ├── Cheat.cpp             # Итерация сущностей, netvars il2cpp, W2S, ESP, аимбот
│   ├── Overlay.cpp           # Внешний оверлей DXGI/D3D11
│   └── Cheat.vcxproj         # Файл проекта MSVC
├── config/                    # Файлы конфигурации
│   └── Config.json           # Оффсеты и настройки под RobRun
└── build.bat                  # Скрипт сборки для Windows
```

---

## Возможности

### ESP (Extra Sensory Perception)
- **Боксы сущностей:** отрисовка ограничивающих рамок вокруг сущностей
- **Полоски здоровья:** отображение здоровья сущности с цветовой индикацией
- **Ники игроков:** показ имён сущностей над боксами
- **Дистанция:** отображение расстояния до каждой сущности
- **Цвет по команде:** раскраска сущностей по принадлежности к команде
- **Линии по костям:** линии между костями головы и позвоночника
- **Круг FOV:** визуальный индикатор FOV для аимбота

### Аимбот
- **Наведение по костям:** наведение в голову и позвоночник
- **Управление FOV:** регулируемый FOV со сглаживанием
- **Предсказание:** предсказание позиции для движущихся целей
- **Silent Aim:** запись напрямую в память игры (меньше детектится)
- **Триггер-бот:** автоматическая стрельба, когда прицел на цели
- **Масштаб FOV:** динамическое масштабирование FOV в зависимости от дистанции

### Радар-хак
- **Радар в реальном времени:** показывает все сущности на радаре
- **Индикаторы направления:** показывает направление сущности относительно игрока
- **Метки дистанции:** показывает расстояние на радаре

### Спидхак
- **Регулируемая скорость:** множитель скорости от 0.1x до 5.0x
- **Плавный переход:** постепенное изменение скорости
- **Настраиваемость:** через Config.json или в рантайме

### Обход EAC
- **DKOM Unlink:** скрытие драйвера из PsLoadedModuleList
- **Патч DSE:** патч Driver Signature Enforcement
- **Переключение PTE-exec:** скрытие страниц драйвера от переписи модулей
- **Срезание прав хендлов:** срезание прав хендла для обхода аудита хендлов EAC
- **Обход переписи модулей:** скрытие от перечисления модулей EAC
- **Обход сканирования хендлов:** уклонение от sweep хендлов EAC

---

## Инструкция по сборке

### Требования

1. **Visual Studio 2022** (или новее) с разработкой настольных приложений на C++
2. **Windows Driver Kit (WDK)** — версия 10.0.22621.0 или новее
3. **DirectX SDK** (для оверлея D3D11/DXGI)

### Шаги сборки

```bash
# Вариант 1: Visual Studio
1. Откройте src/driver/Driver.vcxproj
2. Установите конфигурацию Release|x64
3. Build → Build Solution (Ctrl+Shift+B)
4. Результат: bin/x64/Release/RRToolDriver.sys

# Вариант 2: Командная строка
cd src
build.bat

# Вариант 3: Сборка через WDK
cd src/driver
msbuild Driver.vcxproj /p:Configuration=Release /p:Platform=x64

# Вариант 4: Собрать и драйвер, и чит
cd src/usermode
msbuild Cheat.vcxproj /p:Configuration=Release /p:Platform=x64
```

### Установка драйвера

```bash
# Создать службу драйвера
sc create RRToolDriver binPath= "C:\path\to\RRToolDriver.sys" type= kernel
sc start RRToolDriver

# Проверить, что драйвер загружен
sc query RRToolDriver

# Удалить драйвер
sc stop RRToolDriver
sc delete RRToolDriver
```

---

## Использование

### Запуск чита

```bash
# 1. Запустите ROB RUN
# 2. Запустите чит
RRTool.exe

# 3. Драйвер автоматически найдёт и подключится к процессу ROB RUN
```

### Горячие клавиши

| Клавиша | Действие |
|---------|----------|
| **INSERT** | Переключить видимость оверлея |
| **HOME** | Сбросить позицию оверлея |
| **END** | Выход из чита |
| **F1** | Переключить ESP |
| **F2** | Переключить аимбот |
| **F3** | Переключить триггер-бот |
| **F4** | Переключить радар |
| **F5** | Переключить спидхак |
| **Колесо мыши** | Масштабирование оверлея |

### Конфигурация

Отредактируйте `Config.json`, чтобы настроить чит:

```json
{
  "cheat": {
    "esp": {
      "fov": 90.0,
      "drawDistance": 500.0,
      "showHealth": true,
      "showNames": true
    },
    "aimbot": {
      "fov": 15.0,
      "smoothing": 0.5,
      "prediction": 0.1
    }
  }
}
```

---

## Архитектура

### Драйвер ядра

```
┌──────────────────────────────────────────────────────────────┐
│  RRToolDriver.sys (Ring 0)                                    │
│                                                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │  ЗАГРУЗЧИК  │  │   ОБМЕН     │  │     СКРЫТИЕ         │  │
│  │             │  │             │  │                     │  │
│  │ Патч DSE    │  │ OBJ_KH      │  │ Отвязанный KDT      │  │
│  │ PTE-exec    │  │ Без хендлов │  │ Флип PTE-exec       │  │
│  │ Кэш DTB     │  │ Чтение по PT│  │ Скрытие потоков     │  │
│  └─────────────┘  └─────────────┘  │ Обфускация DPC      │  │
│                                     │ PG-safe хуки        │  │
│  ┌─────────────┐  ┌─────────────┐  └─────────────────────┘  │
│  │   СКРЫТИЕ   │  │   РАЗБОРКА  │                          │  │
│  │             │  │             │                          │  │
│  │ DKOM unlink │  │ Отвязать всё│                          │  │
│  │ Флип PTE    │  │ Восстановить│                          │  │
│  │ Тень CR3    │  │ Патч DSE    │                          │  │
│  └─────────────┘  └─────────────┘                          │  │
└──────────────────────────────────────────────────────────────┘
```

### Чит в юзермоде

```
┌──────────────────────────────────────────────────────────────┐
│  RRTool.exe (Ring 3) — внешний чит                            │
│                                                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   ESP       │  │   АИМБОТ    │  │     ОВЕРЛЕЙ         │  │
│  │             │  │             │  │                     │  │
│  │ Список сущн.│  │ Цель по кост.│ │ Оверлей D3D11/DXGI │  │
│  │ Математика W2S│ │ Контроль FOV│ │ Прозрачное окно    │  │
│  │ Здоровье/Имя│  │ Предсказание│  │ Верхний слой       │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
│                                                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   РАДАР     │  │  СПИДХАК    │  │   КОНФИГ            │  │
│  │             │  │             │  │                     │  │
│  │ Реальное время│ │ Регулируемый│ │ Config.json         │  │
│  │ Направление │  │ Множитель   │  │ Настройки в рантайме│ │
│  │ Дистанция   │  │ Плавный перех│ │ Привязки хоткеев   │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

### Поток данных

```
Процесс игры ROB RUN (Ring 3)
    │
    │  MmCopyVirtualMemory (без хендлов)
    │  KeStackAttachProcess (невидимо для EAC)
    ▼
RRToolDriver.sys (Ring 0)
    │
    │  DeviceIoControl (обмен по IOCTL)
    │  OBJ_KERNEL_HANDLE (уклонение от аудита хендлов)
    ▼
RRTool.exe (Ring 3)
    │
    │  Рендер оверлея D3D11/DXGI
    │  Расчёты ESP, аимбота, радара
    ▼
Экран (оверлей)
```

---

## Детали обхода EAC

### Примитивы обхода

| Техника | Статус | Описание |
|-----------|--------|-------------|
| **DKOM Unlink** | ✅ Активно | Отвязка драйвера из PsLoadedModuleList |
| **Патч DSE** | ✅ Активно | Патч Driver Signature Enforcement (g_CiOptions) |
| **Флип PTE-exec** | ✅ Активно | Скрытие страниц драйвера от переписи модулей |
| **Срезание хендлов** | ✅ Активно | Срезание прав хендла для обхода аудита EAC |
| **Перепись модулей** | ✅ Активно | Скрытие от перечисления модулей EAC |
| **Sweep хендлов** | ✅ Активно | Уклонение от сканирования хендлов EAC |

### Векторы детекта EAC

| Вектор | Статус | Противодействие |
|--------|--------|------------|
| **Перепись модулей** | ✅ Скрыто | DKOM unlink + флип PTE |
| **Аудит хендлов** | ✅ Срезано | Срезание прав хендлов |
| **Скан памяти** | ✅ Безопасно | MmCopyVirtualMemory (без inline-хуков) |
| **Регистрация колбэков** | ✅ Безопасно | EAC НЕ использует ObRegisterCallbacks |
| **Инспекция VAD** | ✅ Безопасно | Флип PTE скрывает страницы драйвера |
| **Подпись драйвера** | ✅ Пропатчено | Патч DSE позволяет неподписанный драйвер |

---

## Оффсеты под RobRun

### BattleEntitiesModel

```cpp
// BattleEntitiesModel (namespace: Game.Battle)
#define OFFSET_BATTLE_ENTITIES_MODEL    0x50   // _entitiesParamsModel
#define OFFSET_ENTITIES_DICT            0x50   // _models (Dictionary base)
#define OFFSET_PLOTS_DICT               0x58   // _plotsModels
#define OFFSET_WORLD_ENTITIES           0x60   // _worldEntitiesModel
#define OFFSET_REPLICATION_GRID         0x68   // _replicationGridLayers
#define OFFSET_CHARACTER_SLOT           0x80   // _characterSlotModel
#define OFFSET_VEHICLES                 0x88   // _vehiclesModel
#define OFFSET_LOCATION_PLOT_SPOTS      0x90   // _locationPlotSpotsModel
#define OFFSET_LOCATION                 0x98   // _location
#define OFFSET_SECTOR                   0xA0   // _sector
#define OFFSET_SETTLEMENT_BONUS         0xA8   // _settlementBonusModel
#define OFFSET_GLOBAL_MODEL             0xB0   // _globalModel
#define OFFSET_TIME_MODEL               0xB8   // _timeModel
#define OFFSET_LAPTOP_DIRTY_CASH        0xC0   // _laptopDirtyCashModel
#define OFFSET_PLOT_GRADE               0xC8   // _plotGrade
#define OFFSET_PLAYER                   0xD0   // _player (PlayerEntityModel)
#define OFFSET_SELF_PLOT                0xD8   // _selfPlot (PlotEntityModel)
#define OFFSET_ENTITY_MODELS            0xE0   // _entityModels
```

### Цепочка костей

```cpp
#define BONE_KVIEW_OFFSET           0x108    // BattleCharacterEntityView
#define BONE_TRANSFORM_OFFSET       0x10     // UnityEngine.Transform
#define BONE_HEAD_ADAPTATION        0x108    // HeadAdaptationManualBehavior
#define BONE_SPINE_ADAPTATION       0xF8     // SpineAdaptationManualBehavior
#define BONE_HEAD_POSITION          0xE8     // <HeadPosition> Transform
#define BONE_HEAD_INDEX             0x40     // boneHead offset
#define BONE_SPINE_INDEX            0x40     // boneSpine offset
#define BONE_TARGET_INDEX           0x28     // _boneTarget Transform
#define BONE_CHAR_VIEWS_COUNT       272      // charViews count
#define BONE_CACHED_PTR             0x10     // m_CachedPtr (Transform)
```

---

## Решение проблем

### Драйвер не загружается

```bash
# Проверить, загружен ли драйвер
sc query RRToolDriver

# Если не загружен — запустить
sc start RRToolDriver

# Проверить лог драйвера
type C:\Windows\System32\drivers\RRToolDriver.log
```

### Детект EAC

Если EAC детектит чит:
1. Убедитесь, что все примитивы обхода активны (проверьте Config.json)
2. Убедитесь, что драйвер отвязан через DKOM
3. Проверьте, что патч DSE применён
4. Проверьте, что флип PTE-exec активен

### Оверлей не отображается

1. Убедитесь, что оверлей не перекрывается окном игры
2. Проверьте, что устройство D3D11 успешно создано
3. Проверьте настройки позиции и размера оверлея

---

## Разработка

### Сборка из исходников

```bash
cd src
build.bat

# Или собрать по отдельности
cd driver
msbuild Driver.vcxproj /p:Configuration=Release

cd ../usermode
msbuild Cheat.vcxproj /p:Configuration=Release
```

### Отладка

```bash
# Включить отладочный вывод
set RRTOOL_DEBUG=1
RRTool.exe

# Подключить отладчик
vsjitdebugger RRTool.exe
```

### Обновление оффсетов

1. Откройте `Config.json`
2. Обновите значения оффсетов
3. Пересоберите и протестируйте

---

## Лицензия

Лицензия MIT — подробности в файле LICENSE.

---

## Благодарности

- **Исследование:** [ac-research](https