// ============================================================================
// Overlay.cpp — D3D11/DXGI External Overlay for ROB RUN
// Renders ESP, aim lines, radar, and other visual elements
// Uses topmost, transparent window that sits on top of the game
// ============================================================================

#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <d3dcompiler.h>
#include <directxmath.h>
#include <iostream>
#include <vector>
#include <string>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3dcompiler.lib")

using namespace DirectX;

// ============================================================================
// Overlay Window Class
// ============================================================================

class OverlayWindow {
public:
    OverlayWindow();
    ~OverlayWindow();

    bool Initialize();
    void Shutdown();
    void Show();
    void Hide();
    void Resize(int width, int height);

    HWND GetHWND() const { return hWnd; }
    bool IsVisible() const { return visible; }

private:
    HWND hWnd;
    IDXGISwapChain* swapChain;
    ID3D11Device* device;
    ID3D11DeviceContext* deviceContext;
    ID3D11RenderTargetView* renderTargetView;
    ID3D11Texture2D* backBuffer;

    int width;
    int height;
    bool visible;
    bool topmost;
    bool transparent;

    // Overlay settings
    float overlayX;
    float overlayY;
    float overlayWidth;
    float overlayHeight;

    // Window class name
    static const wchar_t* className;

    // Window procedure
    static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

    // Internal functions
    bool CreateDeviceAndSwapChain();
    bool CreateRenderTargetView();
    void DestroyResources();
    LRESULT HandleMessage(UINT msg, WPARAM wParam, LPARAM lParam);
};

const wchar_t* OverlayWindow::className = L"RRToolOverlay";

// ============================================================================
// OverlayWindow Implementation
// ============================================================================

OverlayWindow::OverlayWindow()
    : hWnd(NULL), swapChain(NULL), device(NULL), deviceContext(NULL),
      renderTargetView(NULL), backBuffer(NULL),
      width(1920), height(1080), visible(false), topmost(true), transparent(true),
      overlayX(0.0f), overlayY(0.0f), overlayWidth(1920.0f), overlayHeight(1080.0f) {
}

OverlayWindow::~OverlayWindow() {
    Shutdown();
}

bool OverlayWindow::Initialize() {
    WNDCLASSW wc = {0};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.lpszClassName = className;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.style = CS_HREDRAW | CS_VREDRAW;

    if (!RegisterClassW(&wc)) {
        return false;
    }

    // Create window
    DWORD style = WS_POPUP;
    if (topmost) {
        style |= WS_TOPMOST;
    }

    hWnd = CreateWindowExW(
        transparent ? WS_EX_TRANSPARENT | WS_EX_LAYERED : WS_EX_TOPMOST,
        className,
        L"RRTool Overlay",
        style,
        static_cast<int>(overlayX),
        static_cast<int>(overlayY),
        static_cast<int>(overlayWidth),
        static_cast<int>(overlayHeight),
        NULL,
        NULL,
        GetModuleHandle(NULL),
        NULL
    );

    if (!hWnd) {
        return false;
    }

    // Create D3D11 device and swap chain
    if (!CreateDeviceAndSwapChain()) {
        return false;
    }

    // Create render target view
    if (!CreateRenderTargetView()) {
        return false;
    }

    ShowWindow(hWnd, SW_SHOW);
    visible = true;

    return true;
}

void OverlayWindow::Shutdown() {
    if (swapChain) {
        swapChain->SetFullscreenState(FALSE, NULL);
        swapChain->Release();
        swapChain = NULL;
    }

    if (renderTargetView) {
        renderTargetView->Release();
        renderTargetView = NULL;
    }

    if (backBuffer) {
        backBuffer->Release();
        backBuffer = NULL;
    }

    if (deviceContext) {
        deviceContext->Release();
        deviceContext = NULL;
    }

    if (device) {
        device->Release();
        device = NULL;
    }

    if (hWnd) {
        DestroyWindow(hWnd);
        hWnd = NULL;
    }

    UnregisterClassW(className, GetModuleHandle(NULL));
    visible = false;
}

void OverlayWindow::Show() {
    if (hWnd) {
        ShowWindow(hWnd, SW_SHOW);
        visible = true;
    }
}

void OverlayWindow::Hide() {
    if (hWnd) {
        ShowWindow(hWnd, SW_HIDE);
        visible = false;
    }
}

void OverlayWindow::Resize(int width, int height) {
    this->width = width;
    this->height = height;

    if (swapChain && renderTargetView && backBuffer) {
        // Clear render target view
        renderTargetView->Release();
        backBuffer->Release();

        // Create new back buffer
        DXGI_BUFFER_DESC bufferDesc;
        backBuffer->GetDesc(&bufferDesc);
        bufferDesc.Width = width;
        bufferDesc.Height = height;

        // Resize swap chain
        swapChain->ResizeBuffers(2, width, height, bufferDesc.Format, 0);

        // Get new back buffer
        swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&backBuffer);

        // Create new render target view
        device->CreateRenderTargetView(backBuffer, NULL, &renderTargetView);
    }
}

bool OverlayWindow::CreateDeviceAndSwapChain() {
    DXGI_SWAP_CHAIN_DESC swapDesc = {0};
    swapDesc.BufferCount = 2;
    swapDesc.BufferDesc.Width = width;
    swapDesc.BufferDesc.Height = height;
    swapDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    swapDesc.BufferDesc.RefreshRate.Numerator = 60;
    swapDesc.BufferDesc.RefreshRate.Denominator = 1;
    swapDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    swapDesc.OutputWindow = hWnd;
    swapDesc.SampleDesc.Count = 1;
    swapDesc.SampleDesc.Quality = 0;
    swapDesc.Windowed = TRUE;

    D3D11_CREATE_DEVICE_FLAG flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
#ifdef _DEBUG
    flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

    HRESULT hr = D3D11CreateDeviceAndSwapChain(
        NULL,
        D3D_DRIVER_TYPE_HARDWARE,
        NULL,
        flags,
        NULL,
        0,
        D3D11_SDK_VERSION,
        &swapDesc,
        &swapChain,
        &device,
        NULL,
        &deviceContext
    );

    return SUCCEEDED(hr);
}

bool OverlayWindow::CreateRenderTargetView() {
    HRESULT hr = swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&backBuffer);
    if (FAILED(hr)) {
        return false;
    }

    hr = device->CreateRenderTargetView(backBuffer, NULL, &renderTargetView);
    if (FAILED(hr)) {
        backBuffer->Release();
        backBuffer = NULL;
        return false;
    }

    return true;
}

void OverlayWindow::DestroyResources() {
    if (renderTargetView) {
        renderTargetView->Release();
        renderTargetView = NULL;
    }

    if (backBuffer) {
        backBuffer->Release();
        backBuffer = NULL;
    }

    if (deviceContext) {
        deviceContext->Release();
        deviceContext = NULL;
    }

    if (device) {
        device->Release();
        device = NULL;
    }

    if (swapChain) {
        swapChain->Release();
        swapChain = NULL;
    }
}

LRESULT OverlayWindow::WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    OverlayWindow* overlay = NULL;

    if (msg == WM_NCCREATE) {
        CREATESTRUCTW* cs = (CREATESTRUCTW*)lParam;
        overlay = static_cast<OverlayWindow*>(cs->lpCreateParams);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(overlay));
    } else {
        overlay = reinterpret_cast<OverlayWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    }

    if (overlay) {
        return overlay->HandleMessage(msg, wParam, lParam);
    }

    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

LRESULT OverlayWindow::HandleMessage(UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_SIZE: {
            width = LOWORD(lParam);
            height = HIWORD(lParam);
            if (swapChain) {
                // Resize back buffer
                UINT bufferCount = 0;
                swapChain->GetBufferCount(&bufferCount);
                swapChain->ResizeBuffers(bufferCount, width, height, DXGI_FORMAT_R8G8B8A8_UNORM, 0);
            }
            break;
        }

        case WM_PAINT: {
            // Render overlay
            deviceContext->OMSetRenderTargets(1, &renderTargetView, NULL);

            // Clear with transparent background
            float clearColor[4] = {0.0f, 0.0f, 0.0f, 0.0f}; // Transparent black
            deviceContext->ClearRenderTargetView(renderTargetView, clearColor);

            // TODO: Draw ESP, aim lines, radar, etc.
            // Implementation depends on cheat engine data

            swapChain->Present(1, 0);

            ValidateRect(hWnd, NULL);
            break;
        }

        case WM_DESTROY: {
            PostQuitMessage(0);
            break;
        }

        case WM_KEYDOWN: {
            // Handle hotkeys
            switch (wParam) {
                case VK_INSERT:
                    // Toggle overlay visibility
                    if (visible) {
                        Hide();
                    } else {
                        Show();
                    }
                    break;

                case VK_HOME:
                    // Reset overlay position
                    SetWindowPos(hWnd, HWND_TOP, 0, 0, 1920, 1080, SWP_NOMOVE);
                    break;

                case VK_END:
                    // Exit overlay
                    PostQuitMessage(0);
                    break;
            }
            break;
        }

        case WM_MOUSEWHEEL: {
            // Handle zoom
            short zDelta = GET_WHEEL_DELTA_WPARAM(wParam);
            if (zDelta > 0) {
                // Zoom in
                overlayWidth += 50;
                overlayHeight += 50;
            } else {
                // Zoom out
                overlayWidth -= 50;
                overlayHeight -= 50;
            }
            Resize(static_cast<int>(overlayWidth), static_cast<int>(overlayHeight));
            break;
        }

        default:
            return DefWindowProcW(hWnd, msg, wParam, lParam);
    }

    return 0;
}

// ============================================================================
// ESP Renderer
// ============================================================================

class ESPRenderer {
public:
    ESPRenderer();
    ~ESPRenderer();

    void Initialize(ID3D11Device* device, ID3D11DeviceContext* deviceContext);
    void Shutdown();

    void DrawBox(float x, float y, float width, float height, D3DXCOLOR color);
    void DrawLine(float x1, float y1, float x2, float y2, D3DXCOLOR color, float thickness);
    void DrawText(const std::string& text, float x, float y, D3DXCOLOR color, float fontSize);
    void DrawBoneLine(float x1, float y1, float x2, float y2, D3DXCOLOR color);
    void DrawHealthBar(float x, float y, float width, float health, float maxHealth);
    void DrawName(const std::string& name, float x, float y, D3DXCOLOR color);
    void DrawDistance(float x, float y, float distance, D3DXCOLOR color);
    void DrawFOV(float centerX, float centerY, float fov, D3DXCOLOR color);

    void Clear();
    void Render();

private:
    ID3D11Device* device;
    ID3D11DeviceContext* deviceContext;

    // Vertex buffer for primitives
    ID3D11Buffer* vertexBuffer;
    ID3D11Buffer* indexBuffer;
    ID3D11Buffer* constantBuffer;

    // Shader resources
    ID3D11VertexShader* vertexShader;
    ID3D11PixelShader* pixelShader;
    ID3D11InputLayout* inputLayout;
    ID3D11SamplerState* samplerState;

    // Primitive data
    struct Vertex {
        float x, y, z, rhw;
        D3DXCOLOR color;
    };

    std::vector<Vertex> vertices;
    std::vector<UINT> indices;

    // Font rendering (simplified)
    void DrawTextImpl(const std::string& text, float x, float y, D3DXCOLOR color, float fontSize);
};

ESPRenderer::ESPRenderer()
    : device(NULL), deviceContext(NULL), vertexBuffer(NULL), indexBuffer(NULL),
      constantBuffer(NULL), vertexShader(NULL), pixelShader(NULL),
      inputLayout(NULL), samplerState(NULL) {
}

ESPRenderer::~ESPRenderer() {
    Shutdown();
}

void ESPRenderer::Initialize(ID3D11Device* device, ID3D11DeviceContext* deviceContext) {
    this->device = device;
    this->deviceContext = deviceContext;

    // Create shaders (simplified implementation)
    // TODO: Implement proper shader compilation and loading
}

void ESPRenderer::Shutdown() {
    if (samplerState) {
        samplerState->Release();
        samplerState = NULL;
    }

    if (inputLayout) {
        inputLayout->Release();
        inputLayout = NULL;
    }

    if (pixelShader) {
        pixelShader->Release();
        pixelShader = NULL;
    }

    if (vertexShader) {
        vertexShader->Release();
        vertexShader = NULL;
    }

    if (constantBuffer) {
        constantBuffer->Release();
        constantBuffer = NULL;
    }

    if (indexBuffer) {
        indexBuffer->Release();
        indexBuffer = NULL;
    }

    if (vertexBuffer) {
        vertexBuffer->Release();
        vertexBuffer = NULL;
    }
}

void ESPRenderer::DrawBox(float x, float y, float width, float height, D3DXCOLOR color) {
    // Draw a box around the entity
    // Implementation draws 4 lines forming a rectangle
}

void ESPRenderer::DrawLine(float x1, float y1, float x2, float y2, D3DXCOLOR color, float thickness) {
    // Draw a line between two points
    // Implementation adds vertices to the vertex buffer
}

void ESPRenderer::DrawText(const std::string& text, float x, float y, D3DXCOLOR color, float fontSize) {
    // Draw text at the specified position
    // Implementation renders text using D3D11
}

void ESPRenderer::DrawBoneLine(float x1, float y1, float x2, float y2, D3DXCOLOR color) {
    // Draw a line between two bones (e.g., head to spine)
    DrawLine(x1, y1, x2, y2, color, 2.0f);
}

void ESPRenderer::DrawHealthBar(float x, float y, float width, float health, float maxHealth) {
    // Draw health bar below the entity
    // Health is proportional to the bar width
}

void ESPRenderer::DrawName(const std::string& name, float x, float y, D3DXCOLOR color) {
    // Draw entity name above the box
    DrawText(name, x, y, color, 12.0f);
}

void ESPRenderer::DrawDistance(float x, float y, float distance, D3DXCOLOR color) {
    // Draw distance text (e.g., "25m")
    std::string distStr = std::to_string(static_cast<int>(distance)) + "m";
    DrawText(distStr, x, y + 15, color, 10.0f);
}

void ESPRenderer::DrawFOV(float centerX, float centerY, float fov, D3DXCOLOR color) {
    // Draw FOV circle around the center of the screen
    // Implementation draws a circle using line primitives
}

void ESPRenderer::Clear() {
    vertices.clear();
    indices.clear();
}

void ESPRenderer::Render() {
    // Upload vertex data and draw
    // Implementation updates vertex buffer and calls Draw
}

// ============================================================================
// Overlay Renderer (combines window and ESP)
// ============================================================================

class OverlayRenderer {
public:
    OverlayRenderer();
    ~OverlayRenderer();

    bool Initialize();
    void Shutdown();
    void Render();

    OverlayWindow& GetWindow() { return window; }
    ESPRenderer& GetESPRenderer() { return espRenderer; }

private:
    OverlayWindow window;
    ESPRenderer espRenderer;
};

OverlayRenderer::OverlayRenderer() {
}

OverlayRenderer::~OverlayRenderer() {
    Shutdown();
}

bool OverlayRenderer::Initialize() {
    if (!window.Initialize()) {
        return false;
    }

    // Get D3D11 device and context from swap chain
    // Initialize ESP renderer with the device
    espRenderer.Initialize(window.device, window.deviceContext);

    return true;
}

void OverlayRenderer::Shutdown() {
    espRenderer.Shutdown();
    window.Shutdown();
}

void OverlayRenderer::Render() {
    // Render ESP overlay on top of the game
    // This is called every frame from the render thread
}

// ============================================================================
// Global Overlay Renderer
// ============================================================================

OverlayRenderer g_overlay;

// ============================================================================
// Overlay Thread
// ============================================================================

void OverlayThread() {
    // Initialize overlay
    if (g_overlay.Initialize()) {
        std::cout << "Overlay initialized." << std::endl;

        // Render loop
        while (true) {
            g_overlay.Render();
            std::this_thread::sleep_for(std::chrono::milliseconds(16)); // ~60 FPS
        }

        g_overlay.Shutdown();
    }
}

// ============================================================================
// Entry Point for Overlay
// ============================================================================

int OverlayMain() {
    std::cout << "ROB RUN Overlay - RRTool" << std::endl;

    // Start overlay thread
    std::thread overlayThread(OverlayThread);
    overlayThread.join();

    return 0;
}
