// ============================================================================
// Cheat.cpp — ROB RUN External Cheat Core
// ESP, Aimbot, Triggerbot, Radar, Speed Hack
// Communicates with kernel driver via DeviceIoControl
// ============================================================================

#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <iostream>
#include <thread>
#include <vector>
#include <cmath>
#include <atomic>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

// ============================================================================
// Driver IOCTL definitions (matching Driver.h)
// ============================================================================

#define IOCTL_READ_MEMORY         CTL_CODE(FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_WRITE_MEMORY        CTL_CODE(FILE_DEVICE_UNKNOWN, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PROCESS_ATTACH      CTL_CODE(FILE_DEVICE_UNKNOWN, 0x803, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_GET_EPROCESS        CTL_CODE(FILE_DEVICE_UNKNOWN, 0x804, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_DKOM_UNLINK         CTL_CODE(FILE_DEVICE_UNKNOWN, 0x805, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_DSE_PATCH           CTL_CODE(FILE_DEVICE_UNKNOWN, 0x806, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PTE_FLIP            CTL_CODE(FILE_DEVICE_UNKNOWN, 0x807, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_GET_MODULE_BASE     CTL_CODE(FILE_DEVICE_UNKNOWN, 0x808, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_GET_MODULE_HASH     CTL_CODE(FILE_DEVICE_UNKNOWN, 0x809, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_GET_GAME_INFO       CTL_CODE(FILE_DEVICE_UNKNOWN, 0x80A, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_ENABLE_CHEAT        CTL_CODE(FILE_DEVICE_UNKNOWN, 0x80B, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_SET_CHEAT_STATE     CTL_CODE(FILE_DEVICE_UNKNOWN, 0x80C, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_READ_BONE           CTL_CODE(FILE_DEVICE_UNKNOWN, 0x80D, METHOD_BUFFERED, FILE_ANY_ACCESS)

// ============================================================================
// Cheat State Flags (matching Driver.h)
// ============================================================================

#define CHEAT_ESP_ENABLED           (1 << 0)
#define CHEAT_AIMBOT_ENABLED        (1 << 1)
#define CHEAT_TRIGGERBOT_ENABLED    (1 << 2)
#define CHEAT_RADAR_HACK            (1 << 3)
#define CHEAT_SPEED_HACK            (1 << 4)
#define CHEAT_FOV_VISIBLE           (1 << 5)
#define CHEAT_HEALTH_BAR            (1 << 6)
#define CHEAT_PLAYER_NAMES          (1 << 7)
#define CHEAT_DISTANCE_DISPLAY      (1 << 8)
#define CHEAT_TEAM_COLORING         (1 << 9)

// ============================================================================
// Data Structures
// ============================================================================

struct Vector3 {
    float x, y, z;
};

struct Vector2 {
    float x, y;
};

struct Entity {
    ULONG64 address;
    ULONG64 model;
    Vector3 position;
    Vector3 boneHead;
    Vector3 boneSpine;
    float health;
    float maxHealth;
    int teamId;
    int playerId;
    bool isAlive;
    bool isLocal;
    bool isVisible;
    float distance;
    Vector2 screenPos;
    float screenHeight;
    bool hasWeapon;
    std::string name;
};

struct CheatConfig {
    // ESP settings
    float espFov;
    float espDrawDistance;
    bool espShowHealth;
    bool espShowNames;
    bool espShowDistance;
    bool espShowTeamColor;
    bool espShowBoneLines;
    bool espShowBoxes;

    // Aimbot settings
    float aimFov;
    float aimSmoothing;
    float aimPrediction;
    float aimFovScale;
    bool aimBoneHead;
    bool aimBoneSpine;
    bool aimSilent;
    bool aimTrigger;

    // Overlay settings
    float overlayX;
    float overlayY;
    float overlayWidth;
    float overlayHeight;
    bool overlayTopmost;
    bool overlayTransparent;

    // General settings
    float speedMultiplier;
    bool radarHack;
    bool autoAim;
    bool manualMapMode;
    bool dsePatched;
    bool pteFlipped;
    bool dkomUnlinked;
    bool handleStripped;
    bool eacBypassActive;

    // RobRun specific
    ULONG64 gameBase;
    ULONG64 entityList;
    ULONG64 localPlayer;
    ULONG64 battleEntitiesModel;
    ULONG64 il2cppDomain;
    ULONG64 il2cppImage;
    ULONG gamePID;
    ULONG maxEntities;
    ULONG playerCount;
    ULONG characterSlotOffset;
    ULONG worldEntitiesOffset;
    ULONG replicationGridOffset;
};

struct GameInfo {
    ULONG64 entityList;
    ULONG entityCount;
    ULONG64 localPlayer;
    ULONG64 battleEntitiesModel;
    ULONG64 il2cppDomain;
    ULONG64 il2cppImage;
    ULONG playerCount;
    ULONG maxEntities;
};

// ============================================================================
// Cheat Engine Class
// ============================================================================

class CheatEngine {
public:
    CheatEngine();
    ~CheatEngine();

    // Initialization
    bool Initialize();
    void Shutdown();

    // Driver communication
    bool OpenDriver();
    void CloseDriver();
    bool IsDriverOpen() const;

    // Process attachment
    bool AttachToGame();
    void DetachFromGame();
    bool IsAttached() const;

    // ESP
    void UpdateESP();
    void DrawESP();
    std::vector<Entity>& GetEntities();

    // Aimbot
    void UpdateAimbot();
    void FireAimbot();
    Vector3 GetAimTarget();

    // Triggerbot
    void UpdateTriggerbot();
    bool ShouldFire();

    // Radar
    void UpdateRadar();
    void DrawRadar();

    // Speed Hack
    void UpdateSpeedHack();
    void SetSpeedMultiplier(float multiplier);

    // State management
    void ToggleESP();
    void ToggleAimbot();
    void ToggleTriggerbot();
    void ToggleRadar();
    void ToggleSpeedHack();
    void SetCheatState(ULONG state);
    ULONG GetCheatState() const;

    // Configuration
    void LoadConfig(const std::string& path);
    void SaveConfig(const std::string& path);
    CheatConfig& GetConfig();

    // Utility
    Vector3 WorldToScreen(const Vector3& worldPos);
    float GetDistance(const Vector3& a, const Vector3& b);
    bool IsVisible(ULONG64 entityAddress);

private:
    // Driver handle
    HANDLE hDriver;
    std::string driverPath;

    // Cheat state
    ULONG cheatState;
    std::atomic<bool> running;

    // Game data
    GameInfo gameInfo;
    std::vector<Entity> entities;
    Vector3 localPosition;

    // Config
    CheatConfig config;

    // Aiming
    Vector3 aimTarget;
    bool aimReady;
    float currentFov;

    // Triggerbot
    bool triggerReady;
    DWORD lastTriggerTime;

    // Thread
    std::thread mainThread;
    std::thread renderThread;

    // Functions
    void MainLoop();
    void RenderLoop();
    bool ReadGameMemory(ULONG64 address, void* buffer, SIZE_T size);
    bool WriteGameMemory(ULONG64 address, const void* buffer, SIZE_T size);
    bool ReadEntity(ULONG index, Entity& entity);
    void ResolveEntityPosition(Entity& entity);
    void ResolveEntityBones(Entity& entity);
    void ResolveEntityHealth(Entity& entity);
    void ResolveEntityTeam(Entity& entity);
    void ResolveEntityVisibility(Entity& entity);
    void FilterEntities();
    Entity* GetClosestEnemy();
    Entity* GetLocalPlayer();
};

// ============================================================================
// CheatEngine Implementation
// ============================================================================

CheatEngine::CheatEngine()
    : hDriver(NULL), cheatState(0), running(false), aimReady(false), triggerReady(false)
{
    // Default config
    config.espFov = 90.0f;
    config.espDrawDistance = 500.0f;
    config.espShowHealth = true;
    config.espShowNames = true;
    config.espShowDistance = true;
    config.espShowTeamColor = true;
    config.espShowBoneLines = false;
    config.espShowBoxes = true;

    config.aimFov = 15.0f;
    config.aimSmoothing = 0.5f;
    config.aimPrediction = 0.1f;
    config.aimFovScale = 1.0f;
    config.aimBoneHead = true;
    config.aimBoneSpine = false;
    config.aimSilent = false;
    config.aimTrigger = false;

    config.overlayX = 0.0f;
    config.overlayY = 0.0f;
    config.overlayWidth = 1920.0f;
    config.overlayHeight = 1080.0f;
    config.overlayTopmost = true;
    config.overlayTransparent = true;

    config.speedMultiplier = 1.0f;
    config.radarHack = false;
    config.autoAim = false;
    config.manualMapMode = true;
    config.dsePatched = false;
    config.pteFlipped = false;
    config.dkomUnlinked = false;
    config.handleStripped = false;
    config.eacBypassActive = false;

    config.maxEntities = 512;
    config.characterSlotOffset = 0x80;
    config.worldEntitiesOffset = 0x60;
    config.replicationGridOffset = 0x68;

    aimTarget = {0, 0, 0};
    localPosition = {0, 0, 0};
}

CheatEngine::~CheatEngine() {
    Shutdown();
}

bool CheatEngine::Initialize() {
    if (!OpenDriver()) {
        std::cerr << "Failed to open driver" << std::endl;
        return false;
    }

    if (!AttachToGame()) {
        std::cerr << "Failed to attach to game" << std::endl;
        CloseDriver();
        return false;
    }

    running = true;
    mainThread = std::thread(&CheatEngine::MainLoop, this);
    renderThread = std::thread(&CheatEngine::RenderLoop, this);

    return true;
}

void CheatEngine::Shutdown() {
    running = false;

    if (mainThread.joinable()) {
        mainThread.join();
    }
    if (renderThread.joinable()) {
        renderThread.join();
    }

    DetachFromGame();
    CloseDriver();
}

bool CheatEngine::OpenDriver() {
    driverPath = "\\\\.\\\\RRToolDriver";
    hDriver = CreateFileA(
        driverPath.c_str(),
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        0,
        NULL
    );

    return (hDriver != INVALID_HANDLE_VALUE);
}

void CheatEngine::CloseDriver() {
    if (hDriver != INVALID_HANDLE_VALUE) {
        CloseHandle(hDriver);
        hDriver = INVALID_HANDLE_VALUE;
    }
}

bool CheatEngine::IsDriverOpen() const {
    return (hDriver != INVALID_HANDLE_VALUE);
}

bool CheatEngine::AttachToGame() {
    // Find ROB RUN process
    DWORD pid = 0;
    HWND hWnd = FindWindowA(NULL, "RobRun");
    if (hWnd) {
        GetWindowThreadProcessId(hWnd, &pid);
    }

    if (pid == 0) {
        // Fallback: find by process name
        HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        PROCESSENTRY32 pe;
        pe.dwSize = sizeof(PROCESSENTRY32);
        if (Process32First(hSnapshot, &pe)) {
            do {
                if (_stricmp(pe.szExeFile, "RobRun.exe") == 0 ||
                    _stricmp(pe.szExeFile, "RobRunSteam.exe") == 0) {
                    pid = pe.th32ProcessID;
                    break;
                }
            } while (Process32Next(hSnapshot, &pe));
        }
        CloseHandle(hSnapshot);
    }

    if (pid == 0) {
        return false;
    }

    // Send IOCTL to attach
    ULONG ioctlData = pid;
    DWORD bytesReturned;
    BOOL result = DeviceIoControl(
        hDriver,
        IOCTL_PROCESS_ATTACH,
        &ioctlData,
        sizeof(ULONG),
        &ioctlData,
        sizeof(ULONG),
        &bytesReturned,
        NULL
    );

    if (result) {
        gameInfo.entityList = 0;
        gameInfo.localPlayer = 0;
        gameInfo.battleEntitiesModel = 0;
        gameInfo.il2cppDomain = 0;
        gameInfo.il2cppImage = 0;
        gameInfo.playerCount = 0;
        gameInfo.maxEntities = 512;
        config.gamePID = pid;
        config.localPlayer = gameInfo.localPlayer;
        config.battleEntitiesModel = gameInfo.battleEntitiesModel;
        config.il2cppDomain = gameInfo.il2cppDomain;
        config.il2cppImage = gameInfo.il2cppImage;
        return true;
    }

    return false;
}

void CheatEngine::DetachFromGame() {
    if (hDriver != INVALID_HANDLE_VALUE) {
        // Send detach IOCTL
        ULONG ioctlData = 0;
        DWORD bytesReturned;
        DeviceIoControl(
            hDriver,
            IOCTL_PROCESS_ATTACH,
            &ioctlData,
            sizeof(ULONG),
            &ioctlData,
            sizeof(ULONG),
            &bytesReturned,
            NULL
        );
    }
}

bool CheatEngine::IsAttached() const {
    return (config.gamePID != 0);
}

bool CheatEngine::ReadGameMemory(ULONG64 address, void* buffer, SIZE_T size) {
    if (!IsDriverOpen()) {
        return false;
    }

    struct {
        ULONG processId;
        ULONG64 address;
        ULONG size;
        ULONG dataType;
        ULONG reserved;
        ULONG64 output;
    } data = {0};

    data.processId = config.gamePID;
    data.address = address;
    data.size = static_cast<ULONG>(size);
    data.dataType = 1; // uint64

    DWORD bytesReturned;
    return DeviceIoControl(
        hDriver,
        IOCTL_READ_MEMORY,
        &data,
        sizeof(data),
        &data,
        sizeof(data),
        &bytesReturned,
        NULL
    );
}

bool CheatEngine::WriteGameMemory(ULONG64 address, const void* buffer, SIZE_T size) {
    if (!IsDriverOpen()) {
        return false;
    }

    struct {
        ULONG processId;
        ULONG64 address;
        ULONG size;
        ULONG dataType;
        ULONG reserved;
        ULONG64 input;
    } data = {0};

    data.processId = config.gamePID;
    data.address = address;
    data.size = static_cast<ULONG>(size);
    data.dataType = 1; // uint64
    data.input = reinterpret_cast<ULONG64>(buffer);

    DWORD bytesReturned;
    return DeviceIoControl(
        hDriver,
        IOCTL_WRITE_MEMORY,
        &data,
        sizeof(data),
        &data,
        sizeof(data),
        &bytesReturned,
        NULL
    );
}

void CheatEngine::UpdateESP() {
    if (!IsAttached() || !IsDriverOpen()) {
        return;
    }

    // Get game info
    GameInfo info;
    DWORD bytesReturned;
    DeviceIoControl(
        hDriver,
        IOCTL_GET_GAME_INFO,
        NULL,
        0,
        &info,
        sizeof(GameInfo),
        &bytesReturned,
        NULL
    );

    config.entityList = info.entityList;
    config.localPlayer = info.localPlayer;
    config.battleEntitiesModel = info.battleEntitiesModel;
    config.il2cppDomain = info.il2cppDomain;
    config.il2cppImage = info.il2cppImage;
    config.playerCount = info.playerCount;
    config.maxEntities = info.maxEntities;

    // Clear entities
    entities.clear();

    // Read entity list
    for (ULONG i = 0; i < info.maxEntities; i++) {
        Entity entity;
        if (ReadEntity(i, entity)) {
            entities.push_back(entity);
        }
    }

    // Resolve positions and visibility
    for (auto& entity : entities) {
        ResolveEntityPosition(entity);
        ResolveEntityBones(entity);
        ResolveEntityHealth(entity);
        ResolveEntityTeam(entity);
        ResolveEntityVisibility(entity);
        entity.distance = GetDistance(entity.position, localPosition);
        entity.screenPos = WorldToScreen(entity.position);
    }

    // Filter entities based on draw distance
    FilterEntities();
}

void CheatEngine::DrawESP() {
    // ESP drawing is handled by the overlay thread
    // This function updates the entity data for rendering
}

std::vector<Entity>& CheatEngine::GetEntities() {
    return entities;
}

void CheatEngine::UpdateAimbot() {
    if (!(cheatState & CHEAT_AIMBOT_ENABLED)) {
        return;
    }

    Entity* target = GetClosestEnemy();
    if (target) {
        aimTarget = target->boneHead;
        aimReady = true;
        currentFov = config.aimFov * config.aimFovScale;
    } else {
        aimReady = false;
    }
}

void CheatEngine::FireAimbot() {
    if (aimReady && (cheatState & CHEAT_AIMBOT_ENABLED)) {
        // Send mouse input or write to game memory
        // For external cheats, we typically use mouse input
        if (config.aimTrigger && (cheatState & CHEAT_TRIGGERBOT_ENABLED)) {
            // Triggerbot already handles firing
            return;
        }

        // Aim at target
        // Implementation depends on whether aim is silent or regular
        if (config.aimSilent) {
            // Silent aim: write directly to game memory
            // Implementation writes to camera/aim offsets
        } else {
            // Regular aim: move mouse to target
            // Implementation uses SetCursorPos or SendInput
        }
    }
}

Vector3 CheatEngine::GetAimTarget() {
    return aimTarget;
}

void CheatEngine::UpdateTriggerbot() {
    if (!(cheatState & CHEAT_TRIGGERBOT_ENABLED)) {
        triggerReady = false;
        return;
    }

    // Check if crosshair is over an enemy
    Entity* target = GetClosestEnemy();
    if (target && target->isVisible && target->isAlive) {
        DWORD currentTime = GetTickCount();
        if (currentTime - lastTriggerTime > 50) { // 50ms debounce
            triggerReady = true;
            lastTriggerTime = currentTime;
        }
    } else {
        triggerReady = false;
    }
}

bool CheatEngine::ShouldFire() {
    return triggerReady && (cheatState & CHEAT_TRIGGERBOT_ENABLED);
}

void CheatEngine::UpdateRadar() {
    if (!(cheatState & CHEAT_RADAR_HACK)) {
        return;
    }

    // Update radar data
    // Implementation reads entity positions and updates radar overlay
}

void CheatEngine::DrawRadar() {
    // Radar drawing is handled by the overlay thread
}

void CheatEngine::UpdateSpeedHack() {
    if (!(cheatState & CHEAT_SPEED_HACK)) {
        return;
    }

    // Write speed multiplier to game memory
    // Typically writes to a speed-related offset in the player entity
}

void CheatEngine::SetSpeedMultiplier(float multiplier) {
    config.speedMultiplier = multiplier;
    if (multiplier > 0.0f) {
        cheatState |= CHEAT_SPEED_HACK;
    } else {
        cheatState &= ~CHEAT_SPEED_HACK;
    }
}

void CheatEngine::ToggleESP() {
    if (cheatState & CHEAT_ESP_ENABLED) {
        cheatState &= ~CHEAT_ESP_ENABLED;
    } else {
        cheatState |= CHEAT_ESP_ENABLED;
    }
}

void CheatEngine::ToggleAimbot() {
    if (cheatState & CHEAT_AIMBOT_ENABLED) {
        cheatState &= ~CHEAT_AIMBOT_ENABLED;
    } else {
        cheatState |= CHEAT_AIMBOT_ENABLED;
    }
}

void CheatEngine::ToggleTriggerbot() {
    if (cheatState & CHEAT_TRIGGERBOT_ENABLED) {
        cheatState &= ~CHEAT_TRIGGERBOT_ENABLED;
    } else {
        cheatState |= CHEAT_TRIGGERBOT_ENABLED;
    }
}

void CheatEngine::ToggleRadar() {
    if (cheatState & CHEAT_RADAR_HACK) {
        cheatState &= ~CHEAT_RADAR_HACK;
    } else {
        cheatState |= CHEAT_RADAR_HACK;
    }
}

void CheatEngine::ToggleSpeedHack() {
    if (cheatState & CHEAT_SPEED_HACK) {
        cheatState &= ~CHEAT_SPEED_HACK;
        config.speedMultiplier = 1.0f;
    } else {
        cheatState |= CHEAT_SPEED_HACK;
        config.speedMultiplier = 1.5f; // Default speed multiplier
    }
}

void CheatEngine::SetCheatState(ULONG state) {
    cheatState = state;
}

ULONG CheatEngine::GetCheatState() const {
    return cheatState;
}

void CheatEngine::LoadConfig(const std::string& path) {
    // Load configuration from JSON file
    // Implementation reads Config.json and populates config struct
}

void CheatEngine::SaveConfig(const std::string& path) {
    // Save configuration to JSON file
    // Implementation serializes config struct to Config.json
}

CheatConfig& CheatEngine::GetConfig() {
    return config;
}

Vector3 CheatEngine::WorldToScreen(const Vector3& worldPos) {
    // Convert world coordinates to screen coordinates
    // Uses the game's view matrix (typically read from game memory)
    // Simplified implementation:
    Vector2 screen;
    // TODO: Implement proper W2S using game's view matrix
    screen.x = worldPos.x;
    screen.y = worldPos.y;
    return {screen.x, screen.y, worldPos.z};
}

float CheatEngine::GetDistance(const Vector3& a, const Vector3& b) {
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    float dz = a.z - b.z;
    return std::sqrt(dx * dx + dy * dy + dz * dz);
}

bool CheatEngine::IsVisible(ULONG64 entityAddress) {
    // Check if entity is visible (not occluded)
    // Implementation reads visibility flag from entity data
    return true; // Simplified: assume visible
}

void CheatEngine::MainLoop() {
    while (running) {
        UpdateESP();
        UpdateAimbot();
        UpdateTriggerbot();
        UpdateRadar();
        UpdateSpeedHack();

        std::this_thread::sleep_for(std::chrono::milliseconds(16)); // ~60 FPS
    }
}

void CheatEngine::RenderLoop() {
    while (running) {
        // Render loop handles overlay drawing
        // Implementation uses D3D11/DXGI to draw overlay
        std::this_thread::sleep_for(std::chrono::milliseconds(16)); // ~60 FPS
    }
}

bool CheatEngine::ReadEntity(ULONG index, Entity& entity) {
    // Read entity data from entity list
    // Implementation reads entity pointer from entity list at given index
    return true;
}

void CheatEngine::ResolveEntityPosition(Entity& entity) {
    // Resolve entity position from bone data
    // Implementation reads position from entity model
}

void CheatEngine::ResolveEntityBones(Entity& entity) {
    // Resolve head and spine bone positions
    // Uses bone chain offsets from Driver.h
    // Bone positions are read from entity's transform data
}

void CheatEngine::ResolveEntityHealth(Entity& entity) {
    // Read health value from entity data
    // Health is typically stored as a float in the entity model
}

void CheatEngine::ResolveEntityTeam(Entity& entity) {
    // Read team ID from entity data
    // Team ID is used for team coloring in ESP
}

void CheatEngine::ResolveEntityVisibility(Entity& entity) {
    // Check if entity is visible (not occluded)
    // Uses raycast or visibility flag from game data
}

void CheatEngine::FilterEntities() {
    // Filter entities based on draw distance and visibility
    entities.erase(
        std::remove_if(entities.begin(), entities.end(),
            [this](const Entity& e) {
                return e.distance > config.espDrawDistance || !e.isAlive;
            }),
        entities.end()
    );
}

Entity* CheatEngine::GetClosestEnemy() {
    Entity* closest = nullptr;
    float closestDist = FLT_MAX;

    for (auto& entity : entities) {
        if (entity.isAlive && !entity.isLocal && entity.teamId != 0) { // Not local, not dead
            if (entity.distance < closestDist) {
                closestDist = entity.distance;
                closest = &entity;
            }
        }
    }

    return closest;
}

Entity* CheatEngine::GetLocalPlayer() {
    for (auto& entity : entities) {
        if (entity.isLocal) {
            return &entity;
        }
    }
    return nullptr;
}

// ============================================================================
// Global Cheat Engine Instance
// ============================================================================

CheatEngine g_cheat;

// ============================================================================
// Entry Point
// ============================================================================

int main() {
    std::cout << "ROB RUN External Cheat - RRTool" << std::endl;
    std::cout << "Initializing..." << std::endl;

    if (g_cheat.Initialize()) {
        std::cout << "Cheat initialized successfully!" << std::endl;
        std::cout << "Press ESC to exit." << std::endl;

        // Main loop
        while (true) {
            if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) {
                break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        g_cheat.Shutdown();
    } else {
        std::cerr << "Failed to initialize cheat!" << std::endl;
        return 1;
    }

    return 0;
}
