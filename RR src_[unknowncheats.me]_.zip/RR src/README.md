# RRTool — ROB RUN External Kernel Driver Cheat

**Target:** ROB RUN (Steam, il2cpp + EAC)  
**Build:** MSVC + WDK (x64)  
**Date:** 2026-11-15  
**Source:** [UC Thread](https://www.unknowncheats.me/forum/other-fps-games/779959-rob-run-reversal-structs-offsets.html)  
**Research:** [ac-research](https://github.com/ac-research/game-security)

---

## Project Structure

```
src/
├── driver/                    # Kernel driver source
│   ├── Driver.h              # Header: structs, IOCTL codes, RobRun offsets
│   ├── DriverEntry.c         # Entry point, device creation, IOCTL dispatch
│   ├── Memory.c              # MmCopyVirtualMemory, MDL, process attach
│   ├── Hide.c                # DKOM unlink, DSE patch, PTE-exec flip
│   ├── Handle.c              # ObRegisterCallbacks counterplay, handle stripping
│   ├── RRToolDriver.inf      # Driver installation file
│   └── Driver.vcxproj        # MSVC project file
├── usermode/                  # Usermode cheat source
│   ├── Cheat.cpp             # Entity iteration, il2cpp netvars, W2S, ESP, aimbot
│   ├── Overlay.cpp           # DXGI/D3D11 external overlay
│   └── Cheat.vcxproj         # MSVC project file
├── config/                    # Configuration files
│   └── Config.json           # RobRun-specific offsets and settings
└── build.bat                  # Windows build script
```

---

## Features

### ESP (Extra Sensory Perception)
- **Entity Boxes:** Draw bounding boxes around entities
- **Health Bars:** Display entity health with color coding
- **Player Names:** Show entity names above boxes
- **Distance Display:** Show distance to each entity
- **Team Coloring:** Color entities by team affiliation
- **Bone Lines:** Draw lines between head and spine bones
- **FOV Circle:** Visual FOV indicator for aimbot

### Aimbot
- **Bone Targeting:** Head and spine bone aiming
- **FOV Control:** Adjustable FOV with smoothing
- **Prediction:** Aim prediction for moving targets
- **Silent Aim:** Write directly to game memory (less detectable)
- **Trigger Bot:** Automatic firing when crosshair is on target
- **Fov Scale:** Dynamic FOV scaling based on distance

### Radar Hack
- **Real-time Radar:** Shows all entities on radar
- **Direction Indicators:** Shows entity direction relative to player
- **Distance Markers:** Shows distance on radar

### Speed Hack
- **Adjustable Speed:** 0.1x to 5.0x speed multiplier
- **Smooth Transition:** Gradual speed changes
- **Configurable:** Set via Config.json or runtime

### EAC Bypass
- **DKOM Unlink:** Hide driver from PsLoadedModuleList
- **DSE Patch:** Patch Driver Signature Enforcement
- **PTE-exec Flip:** Hide driver pages from module census
- **Handle Stripping:** Strip handle rights to evade EAC handle audit
- **Module Census Evasion:** Hide from EAC module enumeration
- **Handle Sweep Evasion:** Evasion from EAC handle sweep

---

## Build Instructions

### Prerequisites

1. **Visual Studio 2022** (or later) with C++ desktop development
2. **Windows Driver Kit (WDK)** — version 10.0.22621.0 or later
3. **DirectX SDK** (for D3D11/DXGI overlay)

### Build Steps

```bash
# Option 1: Visual Studio
1. Open src/driver/Driver.vcxproj
2. Set configuration to Release|x64
3. Build → Build Solution (Ctrl+Shift+B)
4. Output: bin/x64/Release/RRToolDriver.sys

# Option 2: Command line
cd src
build.bat

# Option 3: WDK build
cd src/driver
msbuild Driver.vcxproj /p:Configuration=Release /p:Platform=x64

# Option 4: Build both driver and cheat
cd src/usermode
msbuild Cheat.vcxproj /p:Configuration=Release /p:Platform=x64
```

### Install Driver

```bash
# Install driver service
sc create RRToolDriver binPath= "C:\path\to\RRToolDriver.sys" type= kernel
sc start RRToolDriver

# Verify driver is loaded
sc query RRToolDriver

# Uninstall driver
sc stop RRToolDriver
sc delete RRToolDriver
```

---

## Usage

### Launch Cheat

```bash
# 1. Start ROB RUN
# 2. Launch the cheat
RRTool.exe

# 3. Driver will auto-detect and attach to ROB RUN process
```

### Hotkeys

| Key | Action |
|-----|--------|
| **INSERT** | Toggle overlay visibility |
| **HOME** | Reset overlay position |
| **END** | Exit cheat |
| **F1** | Toggle ESP |
| **F2** | Toggle Aimbot |
| **F3** | Toggle Triggerbot |
| **F4** | Toggle Radar |
| **F5** | Toggle Speed Hack |
| **Mouse Wheel** | Zoom overlay |

### Configuration

Edit `Config.json` to customize cheat settings:

```json
{
  "cheat": {
    "esp": {
      "fov": 90.0,
      "drawDistance": 500.0,
      "showHealth": true,
      "showNames": true
    },
    "aimbot": {
      "fov": 15.0,
      "smoothing": 0.5,
      "prediction": 0.1
    }
  }
}
```

---

## Architecture

### Kernel Driver

```
┌──────────────────────────────────────────────────────────────┐
│  RRToolDriver.sys (Ring 0)                                    │
│                                                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   LOADER    │  │    COMMS    │  │     HIDING          │  │
│  │             │  │             │  │                     │  │
│  │ DSE patch   │  │ OBJ_KH      │  │ Unlinked KDT       │  │
│  │ PTE-exec    │  │ Handle-less │  │ PTE exec flip      │  │
│  │ DTB cache   │  │ PT read     │  │ Thread hiding      │  │
│  └─────────────┘  └─────────────┘  │ DPC obfuscation    │  │
│                                     │ PG-safe hooking     │  │
│  ┌─────────────┐  ┌─────────────┐  └─────────────────────┘  │
│  │   HIDE      │  │   TEARDOWN  │                          │  │
│  │             │  │             │                          │  │
│  │ DKOM unlink │  │ Unlink all  │                          │  │
│  │ PTE flip    │  │ Restore     │                          │  │
│  │ CR3 shadow  │  │ DSE patch   │                          │  │
│  └─────────────┘  └─────────────┘                          │  │
└──────────────────────────────────────────────────────────────┘
```

### Usermode Cheat

```
┌──────────────────────────────────────────────────────────────┐
│  RRTool.exe (Ring 3) — External Cheat                       │
│                                                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   ESP       │  │   AIMBOT    │  │     OVERLAY         │  │
│  │             │  │             │  │                     │  │
│  │ Entity list │  │ Bone target │  │ D3D11/DXGI overlay │  │
│  │ W2S math    │  │ FOV control │  │ Transparent window │  │
│  │ Health/Name │  │ Prediction  │  │ Topmost layer      │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
│                                                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │  RADAR      │  │  SPEED HAK  │  │   CONFIG            │  │
│  │             │  │             │  │                     │  │
│  │ Real-time   │  │ Adjustable  │  │ Config.json        │  │
│  │ Direction   │  │ Multiplier  │  │ Runtime settings   │  │
│  │ Distance    │  │ Smooth trans│  │ Hotkey bindings    │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

### Data Flow

```
ROB RUN Game Process (Ring 3)
    │
    │  MmCopyVirtualMemory (handle-less)
    │  KeStackAttachProcess (invisible to EAC)
    ▼
RRToolDriver.sys (Ring 0)
    │
    │  DeviceIoControl (IOCTL communication)
    │  OBJ_KERNEL_HANDLE (evasion from handle audit)
    ▼
RRTool.exe (Ring 3)
    │
    │  D3D11/DXGI overlay rendering
    │  ESP, Aimbot, Radar calculations
    ▼
Screen (Overlay)
```

---

## EAC Bypass Details

### Bypass Primitives

| Technique | Status | Description |
|-----------|--------|-------------|
| **DKOM Unlink** | ✅ Active | Unlink driver from PsLoadedModuleList |
| **DSE Patch** | ✅ Active | Patch Driver Signature Enforcement (g_CiOptions) |
| **PTE-exec Flip** | ✅ Active | Hide driver pages from module census |
| **Handle Stripping** | ✅ Active | Strip handle rights to evade EAC audit |
| **Module Census** | ✅ Active | Hide from EAC module enumeration |
| **Handle Sweep** | ✅ Active | Evasion from EAC handle sweep |

### EAC Detection Vectors

| Vector | Status | Mitigation |
|--------|--------|------------|
| **Module Census** | ✅ Hidden | DKOM unlink + PTE flip |
| **Handle Audit** | ✅ Stripped | Handle rights stripping |
| **Memory Scan** | ✅ Safe | MmCopyVirtualMemory (not inline-hooked) |
| **Callback Registration** | ✅ Safe | EAC does NOT use ObRegisterCallbacks |
| **VAD Inspection** | ✅ Safe | PTE flip hides driver pages |
| **Driver Signature** | ✅ Patched | DSE patch allows unsigned driver |

---

## RobRun-Specific Offsets

### BattleEntitiesModel

```cpp
// BattleEntitiesModel (namespace: Game.Battle)
#define OFFSET_BATTLE_ENTITIES_MODEL    0x50   // _entitiesParamsModel
#define OFFSET_ENTITIES_DICT            0x50   // _models (Dictionary base)
#define OFFSET_PLOTS_DICT               0x58   // _plotsModels
#define OFFSET_WORLD_ENTITIES           0x60   // _worldEntitiesModel
#define OFFSET_REPLICATION_GRID         0x68   // _replicationGridLayers
#define OFFSET_CHARACTER_SLOT           0x80   // _characterSlotModel
#define OFFSET_VEHICLES                 0x88   // _vehiclesModel
#define OFFSET_LOCATION_PLOT_SPOTS      0x90   // _locationPlotSpotsModel
#define OFFSET_LOCATION                 0x98   // _location
#define OFFSET_SECTOR                   0xA0   // _sector
#define OFFSET_SETTLEMENT_BONUS         0xA8   // _settlementBonusModel
#define OFFSET_GLOBAL_MODEL             0xB0   // _globalModel
#define OFFSET_TIME_MODEL               0xB8   // _timeModel
#define OFFSET_LAPTOP_DIRTY_CASH        0xC0   // _laptopDirtyCashModel
#define OFFSET_PLOT_GRADE               0xC8   // _plotGrade
#define OFFSET_PLAYER                   0xD0   // _player (PlayerEntityModel)
#define OFFSET_SELF_PLOT                0xD8   // _selfPlot (PlotEntityModel)
#define OFFSET_ENTITY_MODELS            0xE0   // _entityModels
```

### Bone Chain

```cpp
#define BONE_KVIEW_OFFSET           0x108    // BattleCharacterEntityView
#define BONE_TRANSFORM_OFFSET       0x10     // UnityEngine.Transform
#define BONE_HEAD_ADAPTATION        0x108    // HeadAdaptationManualBehavior
#define BONE_SPINE_ADAPTATION       0xF8     // SpineAdaptationManualBehavior
#define BONE_HEAD_POSITION          0xE8     // <HeadPosition> Transform
#define BONE_HEAD_INDEX             0x40     // boneHead offset
#define BONE_SPINE_INDEX            0x40     // boneSpine offset
#define BONE_TARGET_INDEX           0x28     // _boneTarget Transform
#define BONE_CHAR_VIEWS_COUNT       272      // charViews count
#define BONE_CACHED_PTR             0x10     // m_CachedPtr (Transform)
```

---

## Troubleshooting

### Driver Not Loading

```bash
# Check if driver is loaded
sc query RRToolDriver

# If not loaded, start it
sc start RRToolDriver

# Check driver log
type C:\Windows\System32\drivers\RRToolDriver.log
```

### EAC Detection

If EAC detects the cheat:
1. Verify all bypass primitives are active (check Config.json)
2. Ensure driver is DKOM-unlinked
3. Check that DSE patch is applied
4. Verify PTE-exec flip is active

### Overlay Not Showing

1. Ensure overlay is not blocked by game window
2. Check that D3D11 device is created successfully
3. Verify overlay position and size settings

---

## Development

### Building from Source

```bash
cd src
build.bat

# Or build individually
cd driver
msbuild Driver.vcxproj /p:Configuration=Release

cd ../usermode
msbuild Cheat.vcxproj /p:Configuration=Release
```

### Debugging

```bash
# Enable debug output
set RRTOOL_DEBUG=1
RRTool.exe

# Attach debugger
vsjitdebugger RRTool.exe
```

### Updating Offsets

1. Open `Config.json`
2. Update offset values
3. Rebuild and test

---

## License

MIT License — See LICENSE file for details.

---

## Credits

- **Research:** [ac-research](https://github.com/ac-research/game-security)
- **Source:** [UC Thread](https://www.unknowncheats.me/forum/other-fps-games/779959-rob-run-reversal-structs-offsets.html)
- **Anti-cheat Analysis:** EAC EOS 3.2.0, Apex Legends baseline
- **Build:** MSVC + WDK 10.0.22621.0

---

**Version:** 1.0.0  
**Last Updated:** 2026-11-15
